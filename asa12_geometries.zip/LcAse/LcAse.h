// Interface for the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcAse_H_
#define _LcAse_H_


class CLcAse : public ILcMdl
{
public:
	struct AseFce
	{
		union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

		AseFce() : a(0), b(1), c(2){}
		AseFce(WORD A, WORD B, WORD C) : a(A), b(B), c(C){}
		AseFce(WORD* r)					{	a = r[0]; b = r[1];	 c = r[2];	}
		operator WORD*()				{		return (WORD *) &a;			}
		operator const WORD* () const	{		return (CONST WORD *) &a;	}
	};

	typedef char AseKey[64];		// String Keword

	struct AseVtx
	{
		FLOAT x, y, z;
		AseVtx() : x(0), y(0), z(0){}

		enum	{FVF = (D3DFVF_XYZ),};
	};

	struct AseGeo
	{
		char	sNodeName[64];
		INT		iNumVtx;			// Number of Vertex
		INT		iNumFce;			// Number of Index

		AseVtx*	pLstVtx;
		AseFce*	pLstFce;

		AseGeo()
		{
			iNumVtx = 0;
			iNumFce = 0;
			pLstVtx = NULL;
			pLstFce = NULL;

			memset(sNodeName, 0, sizeof sNodeName);
		}

		~AseGeo()
		{
			if(pLstVtx)
			{
				delete [] pLstVtx;
				pLstVtx= NULL;
			}

			if(pLstFce)
			{
				delete [] pLstFce;
				pLstFce = NULL;
			}
		}
	};

protected:
	char		m_sFile[MAX_PATH];		// Model file

	INT			m_nGeo		;
	AseGeo*		m_pGeo		;

	LPDIRECT3DDEVICE9	m_pDev;


public:
	CLcAse();
	virtual ~CLcAse();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();

	virtual	INT		FrameMove();
	virtual void	Render();

protected:
	void	Confirm();
	INT		GetGeoNum();
	INT		GetVtxNum(INT nIdx);
	INT		GetIdxNum(INT nIdx);

	void*	GetVtx(INT nIdx);
	void*	GetIdx(INT nIdx);

protected:
	BOOL	CompareAseKey(char* val, char* key);
	INT		Load();
};

#endif

