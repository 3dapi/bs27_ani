// Interface for the CLcMdl class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcMdl_H_
#define _LcMdl_H_


class CLcMdl : public ILcMdl
{
protected:
	LPDIRECT3DDEVICE9	m_pDev	;
	char		m_sFile[MAX_PATH];

	DOUBLE		m_dFrmCur	;				// Current Frame
	DOUBLE		m_dTimeCur	;				// Current Time
	LCXMATRIX	m_mtWld		;				// World Matrix

public:
	CLcMdl();
	virtual ~CLcMdl();

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		SetAttrib(char* sCmd, void* pData);
	virtual INT		GetAttrib(char* sCmd, void* pData);
	virtual const char*	const GetName() const;

public:
	void*	GetDevice()			{	return m_pDev;	}
};

#endif

