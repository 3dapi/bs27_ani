//
//
////////////////////////////////////////////////////////////////////////////////


#pragma once


#ifndef __StdAfx_H_
#define __StdAfx_H_


#pragma warning( disable : 4018)
#pragma warning( disable : 4100)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)
#pragma warning( disable : 4996)


#define STRICT
#define _WIN32_WINNT			0x0400
#define _WIN32_WINDOWS			0x0400
#define DIRECTINPUT_VERSION		0x0800


#pragma comment(lib, "dinput8.lib")


#include <vector>
#include <list>
#include <map>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <functional>

using namespace std;


#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>

#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>

#include <math.h>
#include <stdio.h>
#include <tchar.h>

#include <D3D9.h>
#include <d3dx9.h>
#include <DxErr.h>

#include <dinput.h>

#include "_d3d/DXUtil.h"

#include "_d3d/D3DEnum.h"
#include "_d3d/D3DSetting.h"
#include "_d3d/D3DApp.h"
#include "resource.h"


#define GHWND		g_pApp->GetHwnd()
#define GDEVICE		g_pApp->GetDevice()


#include "_LcUtil/LcType.h"
#include "_LcUtil/LcUtil.h"
#include "_LcUtil/LcMath.h"

#include "_LcUtil/LcInput.h"
#include "_LcUtil/LcCam.h"
#include "_LcUtil/LcGrid.h"
#include "_LcUtil/LcField.h"

#include "LcAse/ILcMdl.h"




#include "Main.h"

#endif