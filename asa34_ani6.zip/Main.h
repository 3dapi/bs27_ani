// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
public:
	ID3DXFont*		m_pD3DXFont	;
	CLcInput*		m_pInput	;
	CLcCam*			m_pCam		;
	CLcGrid*		m_pGrid		;
	CLcField*		m_pField	;


	ILcMdl*			m_pMdlOrg1	;		// Original
	ILcMdl*			m_pMdlIns1	;		// Instance

	ILcMdl*			m_pMdlOrg2	;		// Original
	ILcMdl*			m_pMdlIns2	;		// Instance

public:
	CMain();

	virtual HRESULT Init();
	virtual HRESULT Destroy();

	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT FrameMove();
	virtual HRESULT Render();
	virtual	LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);

protected:
	HRESULT RenderText();
	INT		LoadMdl(char* sFile);

};


extern CMain*	g_pApp;
#define GMAIN	g_pApp


#endif


