// Interface for the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcAse_H_
#define _LcAse_H_


class CLcAse
{
public:
	typedef char AseKey[64];		// String Keword

	struct AseVtx
	{
		FLOAT x, y, z;
		AseVtx() : x(0), y(0), z(0){}
	};

	struct AseFce
	{
		WORD a, b, c;
		AseFce() : a(0), b(0), c(0){}
	};

	struct AseGeo
	{
		char	sNodeName[64];
		int		iNumVtx;			// Number of Vertex
		int		iNumFce;			// Number of Index

		AseVtx*	pLstVtx;
		AseFce*	pLstFce;

		AseGeo()
		{
			iNumVtx = 0;
			iNumFce = 0;
			pLstVtx = NULL;
			pLstFce = NULL;

			memset(sNodeName, 0, sizeof sNodeName);
		}

		~AseGeo()
		{
			if(pLstVtx)
			{
				delete [] pLstVtx;
				pLstVtx= NULL;
			}

			if(pLstFce)
			{
				delete [] pLstFce;
				pLstFce = NULL;
			}
		}
	};

protected:
	char	m_sFile[MAX_PATH];		// Model file

	INT		m_iNGeo;
	AseGeo*	m_pGeo;

public:
	CLcAse();
	virtual ~CLcAse();

	virtual INT		Create(char* sFile);
	virtual void	Destroy();

	virtual void	Confirm();

protected:
	BOOL	CompareAseKey(char* val, char* key);
	INT		Load();
};

#endif

