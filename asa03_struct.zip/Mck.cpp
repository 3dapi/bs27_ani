
#include <stdio.h>
#include <windows.h>

#include "LcAse.h"


void main()
{
	CLcAse Loader;

	if(FAILED(Loader.Create("Model/asa00_pyramid.ASE")))
		return;

	Loader.Confirm();
	Loader.Destroy();

}