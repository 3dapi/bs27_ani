// Implementation of the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>


#include "ILcMdl.h"
#include "LcAse.h"


#define MAX_PARSE_LINE	512


void LcStr_Trim(char* sBuf)
{
	INT iLen = 0;

	INT	i=0;
	INT iCnt=0;

	iLen = strlen(sBuf);

	if(iLen <1)
		return;


	// ���� \r \n����
	for(i=iLen-1; i>=0; --i)
	{
		char* p = sBuf + i;

		if( '\n' == *p || '\r' == *p)
		{
			*(sBuf + i) = '\0';
		}

		++iCnt;

		if(iCnt>2)
			break;
	}


	// ������ ���� ����
	iCnt = 0;
	iLen = strlen(sBuf);

	for(i=iLen-1; i>=0; --i)
	{
		char* p = sBuf + i;

		if( ' ' == *p || '\t' == *p)
			continue;

		*(sBuf + i+1) = '\0';
		break;
	}

	iLen = i+1 +1;

	// ������ ��������
	char sT[MAX_PARSE_LINE]={0};

	strncpy(sT, sBuf, iLen);

	for(i=0; i < iLen; ++i)
	{
		char* p = sT + i;

		if( ' ' == *p || '\t' == *p)
			continue;

		break;
	}

	strcpy(sBuf, sT+i);
}



void LcStr_Quot(char* sDst, const char* sSrc)
{
	INT iLen = strlen(sSrc);
	INT	nBgn  =-1;
	INT bStrt =0;
	INT iRead =0;

	char* p = (char*)sSrc;

	while( 0 != *p)
	{
		if( '\"' == *p && 0 == bStrt)
			bStrt = 1;

		else if( '\"' == *p && 1 == bStrt)
		{
			*(sDst + nBgn) = 0;
			break;
		}

		if(nBgn>=0 && 1== bStrt)
			*(sDst + nBgn) = *p;

		if(1== bStrt)
			++nBgn;

		++p;
	}
}




CLcAse::CLcAse()
{
	m_iNGeo	= 0;
	m_pGeo	= NULL;


	m_iNVx = 0;
	m_iNIx = 0;

	m_pVtx = NULL;
	m_pIdx = NULL;
}

CLcAse::~CLcAse()
{
	Destroy();
}


INT CLcAse::Create(void* pDev, void* sFile)
{
	INT		i=0;

	m_pDev	= (LPDIRECT3DDEVICE9)pDev;
	strcpy(m_sFile, (char*)sFile);


	if(FAILED(Load()))
		return -1;

	Confirm();



	m_iNVx = this->GetVtxNum(0)	;						// Number of Vertex
	m_iNIx = this->GetIdxNum(0)	;						// Number of Index

	m_pVtx = new VtxD  [m_iNVx]	;								// for vertex buffer
	m_pIdx = new VtxIdx[m_iNIx]	;								// for indexed buffer

	AseVtx* pVtx = (AseVtx*)this->GetVtx(0);
	AseFce* pIdx = (AseFce*)this->GetIdx(0);

	for(i=0;i<m_iNVx; ++i)
	{
		m_pVtx[i].p.x = pVtx[i].x;
		m_pVtx[i].p.y = pVtx[i].y;
		m_pVtx[i].p.z = pVtx[i].z;
	}

	for(i=0;i<m_iNIx; ++i)
	{
		m_pIdx[i].a = pIdx[i].a;
		m_pIdx[i].b = pIdx[i].b;
		m_pIdx[i].c = pIdx[i].c;
	}

	return 0;
}



INT CLcAse::FrameMove()
{
	return 0;
}




void CLcAse::Render()
{
	if(!m_pVtx || !m_pIdx)
		return;

	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);						// Cull Mode�� ����
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);					// Wire Frame���� ����.
	m_pDev->SetTexture(0,0);
	m_pDev->SetFVF(VtxD::FVF);

	m_pDev->DrawIndexedPrimitiveUP(
								D3DPT_TRIANGLELIST
								, 0					// Minimum Vertex Index
								, m_iNVx			// Number vertex indices
								, m_iNIx			// Primitive Count
                                , m_pIdx			// IndexData pointer
								, D3DFMT_INDEX16	// Index Data format
								, m_pVtx			// Vetex stream zero data
								, sizeof(VtxD)	// Vertex Stream Zero Stride
								);

	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);						// �ٽ� Solid
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);						// Cull Mode �ٽ� ����
}


void CLcAse::Destroy()
{
	m_iNGeo	= 0;

	if(m_pGeo)	{	delete [] m_pGeo;	m_pGeo = NULL;	}

	if(m_pVtx)	{	delete [] m_pVtx;	m_pVtx = NULL;	}
	if(m_pIdx)	{	delete [] m_pIdx;	m_pIdx = NULL;	}
}



INT CLcAse::GetGeoNum()
{
	return m_iNGeo;
}

INT CLcAse::GetVtxNum(INT nIdx)
{
	return m_pGeo[nIdx].iNumVtx;
}

INT CLcAse::GetIdxNum(INT nIdx)
{
	return m_pGeo[nIdx].iNumFce;
}

void*  CLcAse::GetVtx(INT nIdx)
{
	return m_pGeo[nIdx].pLstVtx;
}

void*  CLcAse::GetIdx(INT nIdx)
{
	return m_pGeo[nIdx].pLstFce;
}






// Parsing Keyword
CLcAse::AseKey	Keywords[] =
{
	"*GEOMOBJECT {"			,	// 0
	"*NODE_NAME"			,	// 1
	"*NODE_TM {"			,	// 2
	"*MESH {"				,	// 3
	"*MESH_NUMVERTEX"		,	// 4
	"*MESH_NUMFACES"		,	// 5
	"*MESH_VERTEX_LIST {"	,	// 6
	"*MESH_VERTEX"			,	// 7
	"*MESH_FACE_LIST {"		,	// 8
	"*MESH_FACE"			,	// 9
};







BOOL CLcAse::CompareAseKey(char* val, char* key)
{
	return (0 == _strnicmp(val, key, strlen(key) ) ) ? 1: 0;
}



INT CLcAse::Load()
{
	FILE*	fp;
	char	sLine[MAX_PARSE_LINE];

	fp = fopen(m_sFile, "rt");



	if(NULL == fp)
		return -1;



	//�ϴ� Geometry�� �ϳ��� �ִٰ� ��������.
	m_iNGeo	= 1;
	m_pGeo = new AseGeo[m_iNGeo];
	INT	nGeoIdx = 0;
	//

	while(!feof(fp))
	{
		fgets(sLine, MAX_PARSE_LINE, fp);
		LcStr_Trim(sLine);


		if(CompareAseKey(sLine, Keywords[0]) )
		{
			while(!feof(fp))
			{
				fgets(sLine, MAX_PARSE_LINE, fp);
				LcStr_Trim(sLine);

				if('}' == sLine[0])
					break;

				if(CompareAseKey(sLine, Keywords[1]) )
				{
					char	sName[64];

//					sscanf(sLine, "%*s %s", sName1);
					LcStr_Quot(sName, sLine);

					strcpy(m_pGeo[nGeoIdx].sNodeName, sName);
				}

				else if(CompareAseKey(sLine, Keywords[2]) )
				{
					while(!feof(fp))
					{
						fgets(sLine, MAX_PARSE_LINE, fp);
						LcStr_Trim(sLine);

						if('}' == sLine[0])
							break;
					}
				}

				else if(CompareAseKey(sLine, Keywords[3]) )
				{
					while(!feof(fp))
					{
						fgets(sLine, MAX_PARSE_LINE, fp);
						LcStr_Trim(sLine);

						if('}' == sLine[0])
							break;

						if(CompareAseKey(sLine, Keywords[4]) )
						{
							INT		iNVx;
							sscanf(sLine, "%*s %d", &iNVx);

							m_pGeo[nGeoIdx].iNumVtx = iNVx;
							m_pGeo[nGeoIdx].pLstVtx = new CLcAse::AseVtx[iNVx];
						}

						if(CompareAseKey(sLine, Keywords[5]) )
						{
							INT		iNIx;
							sscanf(sLine, "%*s %d", &iNIx);

							m_pGeo[nGeoIdx].iNumFce = iNIx;
							m_pGeo[nGeoIdx].pLstFce = new CLcAse::AseFce[iNIx];
						}


						if(CompareAseKey(sLine, Keywords[6]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LcStr_Trim(sLine);

								if('}' == sLine[0])
									break;

								if(CompareAseKey(sLine, Keywords[7]) )
								{
									INT		nIdx=0;
									FLOAT	x=0.F, y=0.F, z=0.F;
									sscanf(sLine, "%*s %d %f %f %f", &nIdx, &x, &y, &z);

									m_pGeo[nGeoIdx].pLstVtx[nIdx].x = x;
									m_pGeo[nGeoIdx].pLstVtx[nIdx].y = z;
									m_pGeo[nGeoIdx].pLstVtx[nIdx].z = y;
								}

							}
						}

						if(CompareAseKey(sLine, Keywords[8]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LcStr_Trim(sLine);

								if('}' == sLine[0])
									break;

								if(CompareAseKey(sLine, Keywords[9]) )
								{
									INT	nIdx=0, a=0, b=0, c=0;

//									           *MESH_FACE 0:   A:  0  B: 1  C:  2
									sscanf(sLine, "%*s    %d: %*s %d %*s %d %*s %d", &nIdx, &a, &b, &c);

									m_pGeo[nGeoIdx].pLstFce[nIdx].a = a;
									m_pGeo[nGeoIdx].pLstFce[nIdx].b = c;
									m_pGeo[nGeoIdx].pLstFce[nIdx].c = b;

								}

							}// while
						}// if

					}// while
				}// if



			}// while
		}// if


	}// while

	fclose(fp);

	return 0;
}




void CLcAse::Confirm()
{
	FILE*	fp;
	INT		i=0, j=0;


	char	sDst[260]={0};
	strcpy(sDst, m_sFile);
	char * p = strchr(sDst, '.');
	*p = '\0';
	strcat(p, ".txt");


	fp= fopen(sDst, "wt");
	if(NULL == fp)
		return;


	for(i=0; i<m_iNGeo; ++i)
	{
		fprintf(fp, "%s\n", Keywords[0]);
		fprintf(fp, "	%s	\"%s\"\n", Keywords[1], m_pGeo[i].sNodeName);
		fprintf(fp, "	%s\n", Keywords[2]);

		fprintf(fp, "		%s	%d\n", Keywords[4], m_pGeo[i].iNumVtx);
		fprintf(fp, "		%s	%d\n", Keywords[5], m_pGeo[i].iNumFce);

		fprintf(fp, "		%s\n"	, Keywords[6]);


		INT iNumVtx = m_pGeo[i].iNumVtx;

		for(j=0; j<iNumVtx; ++j)
		fprintf(fp, "			%s	%f	%f	%f\n", Keywords[7]
										, m_pGeo[i].pLstVtx[j].x
										, m_pGeo[i].pLstVtx[j].y
										, m_pGeo[i].pLstVtx[j].z);

		fprintf(fp, "		}\n\n");

		fprintf(fp, "		%s\n"	, Keywords[8]);

		INT iNumFce = m_pGeo[i].iNumFce;

		for(j=0; j<iNumFce; ++j)
		fprintf(fp, "			%s	%u	%u	%u\n", Keywords[9]
										, m_pGeo[i].pLstFce[j].a
										, m_pGeo[i].pLstFce[j].b
										, m_pGeo[i].pLstFce[j].c);

		fprintf(fp, "		}\n");

		fprintf(fp, "	}\n");

		fprintf(fp, "}\n");
	}


	fclose(fp);
}

