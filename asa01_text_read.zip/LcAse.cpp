// Implementation of the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>

#include "LcAse.h"


#define MAX_PARSE_LINE	512


void LcStr_Trim(char* sBuf)
{
	int iLen = 0;

	int	i=0;
	int iCnt=0;

	iLen = strlen(sBuf);

	if(iLen <1)
		return;


	// ���� \r \n����
	for(i=iLen-1; i>=0; --i)
	{
		char* p = sBuf + i;

		if( '\n' == *p || '\r' == *p)
		{
			*(sBuf + i) = '\0';
		}

		++iCnt;

		if(iCnt>2)
			break;
	}


	// ������ ���� ����
	iCnt = 0;
	iLen = strlen(sBuf);

	for(i=iLen-1; i>=0; --i)
	{
		char* p = sBuf + i;

		if( ' ' == *p || '\t' == *p)
			continue;

		*(sBuf + i+1) = '\0';
		break;
	}

	iLen = i+1 +1;

	// ���� ���� ����
	char sT[MAX_PARSE_LINE]={0};

	strncpy(sT, sBuf, iLen);

	for(i=0; i < iLen; ++i)
	{
		char* p = sT + i;

		if( ' ' == *p || '\t' == *p)
			continue;

		break;
	}

	strcpy(sBuf, sT+i);
}


CLcAse::CLcAse()
{
}

CLcAse::~CLcAse()
{
	Destroy();
}


INT CLcAse::Create(char* sFile)
{
	strcpy(m_sFile, sFile);


	if(FAILED(Load()))
		return -1;

	Confirm();

	return 0;
}

void CLcAse::Destroy()
{
}


INT CLcAse::Load()
{
	FILE*	fp;						// ASE source file
	FILE*	fpCnf;					// confrim file
	char sLine[MAX_PARSE_LINE];		// read line buffer to read

	if(!(fp = fopen(m_sFile, "rt")))
		return -1;


	char	sDst[260]={0};
	strcpy(sDst, m_sFile);
	char * p = strchr(sDst, '.');
	*p = '\0';
	strcat(p, ".txt");


	fpCnf= fopen(sDst, "wt");


	while(!feof(fp))
	{
		fgets(sLine, MAX_PARSE_LINE, fp);

		int iLen = strlen(sLine);

		if(iLen<3)
			continue;


		LcStr_Trim(sLine);			// get rid of the space, tab, line feed back

		// Write to confrim file
		fprintf(fpCnf, "%s\n", sLine);

	}// while

	fclose(fp);
	fclose(fpCnf);

	return 0;
}

void CLcAse::Confirm()
{
}


