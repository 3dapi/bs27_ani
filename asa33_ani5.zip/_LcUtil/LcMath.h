//
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _LcMath_H_
#define _LcMath_H_


#include <math.h>


#define LCX_PI		3.1415926535897932384626433832795f

#define LCXToRadian( d ) ( (d) * LCX_PI / 180.0f )
#define LCXToDegree( r ) ( (r) * 180.0f / LCX_PI )


typedef int					INT;
typedef int					BOOL;
typedef float				FLOAT;
typedef unsigned long		DWORD;


struct LCXVECTOR2
{
	union {	struct { FLOAT x; FLOAT y; };	FLOAT m[2];	};

	LCXVECTOR2();
	LCXVECTOR2(const FLOAT* v);
	LCXVECTOR2(const LCXVECTOR2& v);
	LCXVECTOR2(const LCXVECTOR2* v);
	LCXVECTOR2(FLOAT X, FLOAT Y);

	operator FLOAT*();
	operator const FLOAT*() const;

	FLOAT& operator[](int n);

	// assignment operators
	LCXVECTOR2& operator +=(const LCXVECTOR2& v);
	LCXVECTOR2& operator -=(const LCXVECTOR2& v);
	LCXVECTOR2& operator *=(FLOAT v);
	LCXVECTOR2& operator /=(FLOAT v);

	// unary operators
	LCXVECTOR2 operator +() const;
	LCXVECTOR2 operator -() const;

	// binary operators
	LCXVECTOR2 operator +(const LCXVECTOR2& v) const;
	LCXVECTOR2 operator -(const LCXVECTOR2& v) const;
	LCXVECTOR2 operator *(FLOAT v) const;
	LCXVECTOR2 operator /(FLOAT v) const;

	friend LCXVECTOR2 operator *(FLOAT f, const LCXVECTOR2& v);
	friend LCXVECTOR2 operator /(FLOAT f, const LCXVECTOR2& v);

	BOOL operator ==(const LCXVECTOR2& v) const;
	BOOL operator !=(const LCXVECTOR2& v) const;

	FLOAT operator *(const LCXVECTOR2& v);										// Dot Product
	friend FLOAT operator *(const LCXVECTOR2& v1, const LCXVECTOR2& v2);

	FLOAT operator ^(const LCXVECTOR2& v);										// Cross Product(Z-Value)
	friend FLOAT operator ^(const LCXVECTOR2& v1, const LCXVECTOR2& v2);

	LCXVECTOR2 operator *(const FLOAT* v);										// Transform: vector * Matrix
	friend LCXVECTOR2 operator *(const FLOAT* v1, const LCXVECTOR2& v2);			// Transform: Matrix * vector;

	FLOAT		Length();														// Length
	FLOAT		LengthSq();														// Length Square
	LCXVECTOR2	Normalize();
};


struct LCXVECTOR3
{
	union {	struct { FLOAT x; FLOAT y; FLOAT z; };	FLOAT m[3];	};

	LCXVECTOR3();
	LCXVECTOR3(const FLOAT* v);
	LCXVECTOR3(const LCXVECTOR3& v);
	LCXVECTOR3(const LCXVECTOR3* v);
	LCXVECTOR3(FLOAT X, FLOAT Y, FLOAT Z);

	operator FLOAT*();
	operator const FLOAT*() const;

	FLOAT& operator[](int n);

	// assignment operators
	LCXVECTOR3& operator +=(const LCXVECTOR3& v);
	LCXVECTOR3& operator -=(const LCXVECTOR3& v);
	LCXVECTOR3& operator *=(FLOAT v);
	LCXVECTOR3& operator /=(FLOAT v);

	// unary operators
	LCXVECTOR3 operator +() const;
	LCXVECTOR3 operator -() const;

	// binary operators
	LCXVECTOR3 operator +(const LCXVECTOR3& v) const;
	LCXVECTOR3 operator -(const LCXVECTOR3& v) const;
	LCXVECTOR3 operator *(FLOAT v) const;
	LCXVECTOR3 operator /(FLOAT v) const;

	friend LCXVECTOR3 operator *(FLOAT f, const LCXVECTOR3& v);
	friend LCXVECTOR3 operator /(FLOAT f, const LCXVECTOR3& v);

	BOOL operator ==(const LCXVECTOR3& v) const;
	BOOL operator !=(const LCXVECTOR3& v) const;

	FLOAT operator *(const LCXVECTOR3& v);										// Dot Product
	friend FLOAT operator *(const LCXVECTOR3& v1, const LCXVECTOR3& v2);

	LCXVECTOR3 operator ^(const LCXVECTOR3& v);									// Cross Product
	friend LCXVECTOR3 operator ^(const LCXVECTOR3& v1, const LCXVECTOR3& v2);

	LCXVECTOR3 operator *(const FLOAT* v);										// Transform: vector * Matrix
	friend LCXVECTOR3 operator *(const FLOAT* v1, const LCXVECTOR3& v2);			// Transform: Matrix * vector;

	FLOAT		Length();														// Length
	FLOAT		LengthSq();														// Length Square
	LCXVECTOR3	Normalize();
	LCXVECTOR3	Normalize(const LCXVECTOR3* v);
};



struct LCXMATRIX
{
	union
	{
		struct
		{
			FLOAT _11, _12, _13, _14;
			FLOAT _21, _22, _23, _24;
			FLOAT _31, _32, _33, _34;
			FLOAT _41, _42, _43, _44;

		};
		FLOAT m[4][4];
	};

	LCXMATRIX();
	LCXMATRIX(const FLOAT* v);
	LCXMATRIX(const LCXMATRIX& v);
	LCXMATRIX(	FLOAT v11, FLOAT v12, FLOAT v13, FLOAT v14,
		FLOAT v21, FLOAT v22, FLOAT v23, FLOAT v24,
		FLOAT v31, FLOAT v32, FLOAT v33, FLOAT v34,
		FLOAT v41, FLOAT v42, FLOAT v43, FLOAT v44 );


	// access grants
	FLOAT& operator () ( int iRow, int iCol );
	FLOAT  operator () ( int iRow, int iCol ) const;

	// casting operators
	operator FLOAT* ();
	operator const FLOAT* () const;

	// assignment operators
	LCXMATRIX& operator *= (const LCXMATRIX& v);
	LCXMATRIX& operator += (const LCXMATRIX& v);
	LCXMATRIX& operator -= (const LCXMATRIX& v);
	LCXMATRIX& operator *= ( FLOAT v);
	LCXMATRIX& operator /= ( FLOAT v);

	LCXMATRIX operator +() const;												// unary operators
	LCXMATRIX operator -() const;

	LCXMATRIX operator * (const LCXMATRIX& v) const;
	LCXMATRIX operator + (const LCXMATRIX& v) const;
	LCXMATRIX operator - (const LCXMATRIX& v) const;
	LCXMATRIX operator * ( FLOAT v) const;
	LCXMATRIX operator / ( FLOAT v) const;


	friend LCXMATRIX operator * (FLOAT f, const LCXMATRIX& v);
	friend LCXMATRIX operator * (const LCXMATRIX& v, FLOAT f);

	BOOL operator == (const LCXMATRIX& v) const;
	BOOL operator != (const LCXMATRIX& v) const;

	LCXMATRIX&	Identity();
	LCXMATRIX&	Transpose();
	LCXMATRIX&	Transpose(const LCXMATRIX* v);
	LCXMATRIX&	Inverse();
	LCXMATRIX&	Inverse(const LCXMATRIX* v);
	FLOAT		Determinant();

	LCXMATRIX&	SetupViewRH(const LCXVECTOR3* vEye, const LCXVECTOR3* vLook, const LCXVECTOR3* vUp );
	LCXMATRIX&	SetupPerspectiveRH(FLOAT fFOV, FLOAT fAspect, FLOAT fNear, FLOAT fFar);
	LCXMATRIX&	SetupRotationX(FLOAT fRad);
	LCXMATRIX&	SetupRotationY(FLOAT fRad);
	LCXMATRIX&	SetupRotationZ(FLOAT fRad);
	LCXMATRIX&	SetupRotationAxis(const LCXVECTOR3* vAxis, FLOAT fRad);
	LCXMATRIX&	SetupTranslation(const LCXVECTOR3* vTrs, BOOL bInit=TRUE);

	void		TransformCoord(LCXVECTOR3* pOut, const LCXVECTOR3* pIn);
};






struct LCXQUATERNION
{
	union {	struct { FLOAT x; FLOAT y; FLOAT z;	 FLOAT w; }; FLOAT m[4]; };

	LCXQUATERNION();
	LCXQUATERNION( const FLOAT * );
	LCXQUATERNION( const LCXQUATERNION& );
	LCXQUATERNION( FLOAT x, FLOAT y, FLOAT z, FLOAT w );

	// casting
	operator FLOAT* ();
	operator const FLOAT* () const;

	// assignment operators
	LCXQUATERNION& operator += ( const LCXQUATERNION& );
	LCXQUATERNION& operator -= ( const LCXQUATERNION& );
	LCXQUATERNION& operator *= ( const LCXQUATERNION& );
	LCXQUATERNION& operator *= ( FLOAT );
	LCXQUATERNION& operator /= ( FLOAT );

	// unary operators
	LCXQUATERNION  operator + () const;
	LCXQUATERNION  operator - () const;

	// binary operators
	LCXQUATERNION operator + ( const LCXQUATERNION& ) const;
	LCXQUATERNION operator - ( const LCXQUATERNION& ) const;
	LCXQUATERNION operator * ( const LCXQUATERNION& ) const;
	LCXQUATERNION operator * ( FLOAT ) const;
	LCXQUATERNION operator / ( FLOAT ) const;

	friend LCXQUATERNION operator * (FLOAT, const LCXQUATERNION& );

	BOOL operator == ( const LCXQUATERNION& ) const;
	BOOL operator != ( const LCXQUATERNION& ) const;


	void SLerp(const LCXQUATERNION* q1, const LCXQUATERNION* q2, FLOAT t);
	void RotationMatrix(LCXMATRIX* pOut);
};


// Planes
struct LCXPLANE
{
	union {	struct { FLOAT a; FLOAT b; FLOAT c;	 FLOAT d; }; FLOAT m[4]; };

	LCXPLANE();
	LCXPLANE( const FLOAT* );
	LCXPLANE( const LCXPLANE& );
	LCXPLANE( FLOAT a, FLOAT b, FLOAT c, FLOAT d );

	// casting
	operator FLOAT* ();
	operator const FLOAT* () const;

	// unary operators
	LCXPLANE operator + () const;
	LCXPLANE operator - () const;

	// binary operators
	BOOL operator == ( const LCXPLANE& ) const;
	BOOL operator != ( const LCXPLANE& ) const;

	void SetupFromPointNormal(const LCXVECTOR3* point, const LCXVECTOR3* normal);
	void SetupFromPoints(const LCXVECTOR3* p0, const LCXVECTOR3* p1, const LCXVECTOR3* p2);
};



// Colors
struct LCXCOLOR
{
	union {	struct { FLOAT r; FLOAT g; FLOAT b;	 FLOAT a; }; FLOAT m[4]; };

	LCXCOLOR();
	LCXCOLOR( DWORD argb );
	LCXCOLOR( const FLOAT * );
	LCXCOLOR( const LCXCOLOR& );
	LCXCOLOR( FLOAT r, FLOAT g, FLOAT b, FLOAT a );

	// casting
	operator DWORD () const;

	operator FLOAT* ();
	operator const FLOAT* () const;

	// assignment operators
	LCXCOLOR& operator += ( const LCXCOLOR& );
	LCXCOLOR& operator -= ( const LCXCOLOR& );
	LCXCOLOR& operator *= ( FLOAT );
	LCXCOLOR& operator /= ( FLOAT );

	// unary operators
	LCXCOLOR operator + () const;
	LCXCOLOR operator - () const;

	// binary operators
	LCXCOLOR operator + ( const LCXCOLOR& ) const;
	LCXCOLOR operator - ( const LCXCOLOR& ) const;
	LCXCOLOR operator * ( FLOAT ) const;
	LCXCOLOR operator / ( FLOAT ) const;

	friend LCXCOLOR operator * (FLOAT, const LCXCOLOR& );

	BOOL operator == ( const LCXCOLOR& ) const;
	BOOL operator != ( const LCXCOLOR& ) const;
};




#endif



