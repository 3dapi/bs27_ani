// Implementation of the CLcMdl class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>


#include "../_LcUtil/LcMath.h"

#include "ILcMdl.h"
#include "LcMdl.h"


CLcMdl::CLcMdl()
{
	m_pDev	= NULL;

	memset(m_sFile, 0, sizeof m_sFile);

	m_dFrmCur = 0;
	m_dTimeCur= 0;
	m_mtWld.Identity();
}

CLcMdl::~CLcMdl()
{
	Destroy();
}


INT CLcMdl::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev	= (LPDIRECT3DDEVICE9)p1;
	strcpy(m_sFile, (char*)p2);

	return 0;
}


void CLcMdl::Destroy()
{
}


INT CLcMdl::FrameMove()
{
	return -1;
}




void CLcMdl::Render()
{
}


INT CLcMdl::SetAttrib(char* sCmd, void* pData)
{
	return -1;
}


INT CLcMdl::GetAttrib(char* sCmd, void* pData)
{
	return -1;
}

const char*	const CLcMdl::GetName() const
{
	return m_sFile;
}



