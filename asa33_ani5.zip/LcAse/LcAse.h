// Interface for the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcAse_H_
#define _LcAse_H_


#pragma warning( disable : 4996)


#include <vector>


class CLcAse : public CLcMdl
{
public:
	typedef char _AseKey[64];		// String Keword

	struct _AseFce
	{
		WORD a;	WORD b;	WORD c;
		_AseFce() : a(0), b(0), c(0){}
	};

	struct _AsePos
	{
		FLOAT	x, y, z;
		_AsePos() : x(0), y(0), z(0){}
	};

	struct _AseNor
	{
		FLOAT	x, y, z;
		INT		a, b, c;
		_AseNor() : x(0), y(0), z(0), a(0), b(0), c(0){}
	};

	struct _AseTvtx
	{
		INT		nT;					// �迭���� ���� �Ǵ� UV�� �ε���
		FLOAT	u, v, w;			// UVW��ǥ

		_AseTvtx() :nT(-1), u(0), v(0), w(0){}
	};

	struct AseMtl
	{
		char				sTex[MAX_PATH];
		D3DXIMAGE_INFO		pImg;
		LPDIRECT3DTEXTURE9	pTex;

		AseMtl();
		~AseMtl();
	};

	struct AseIdx
	{
		union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

		AseIdx() : a(0), b(1), c(2){}
		AseIdx(WORD A, WORD B, WORD C) : a(A), b(B), c(C){}
		AseIdx(WORD* r)					{	a = r[0]; b = r[1];	 c = r[2];	}
		operator WORD*()				{	return (WORD *) &a;				}
		operator const WORD* () const	{	return (const WORD *) &a;		}
	};

	struct AseVtx
	{
		LCXVECTOR3	p;
		AseVtx() : p(0,0,0){}
		enum	{FVF = (D3DFVF_XYZ),};
	};

//	struct AseVtxN
//	{
//		LCXVECTOR3	p;
//		LCXVECTOR3	n;
//
//		AseVtxN() : p(0,0,0), n(0,0,0){}
//		enum	{FVF = (D3DFVF_XYZ|D3DFVF_NORMAL),};
//	};

	struct AseVtxUV
	{
		LCXVECTOR3	p;
		FLOAT	u, v;

		AseVtxUV() : p(0,0,0), u(0),v(0){}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_TEX1),};
	};

//	struct AseVtxNUV
//	{
//		LCXVECTOR3	p;
//		LCXVECTOR3	n;
//		FLOAT	u, v;
//
//		AseVtxNUV() : p(0,0,0), n(0,0,0), u(0),v(0){}
//		enum	{FVF = (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1),};
//	};

	struct AseTM
	{
		LCXMATRIX	mtW;							// World Matrix
		LCXMATRIX	mtL;							// Local Matirx

		FLOAT	Px, Py, Pz;
		FLOAT	Rx, Ry, Rz, Rw;
		FLOAT	Sx, Sy, Sz;

		AseTM() : Px(0), Py(0), Pz(0)
				, Rx(0), Ry(0), Rz(0), Rw(0)
				, Sx(0), Sy(0), Sz(0){}
	};

	struct AseScene
	{
		char	sVer[16];								// For Converting Binary version
		INT		nFrmF	;								// First Frame
		INT		nFrmL	;								// Last Frame
		INT		nFrmS	;								// Frame Speed Per one scecond
		INT		nFrmT	;								// Tick per one Frame

		AseScene():nFrmF(0),nFrmL(0),nFrmS(0),nFrmT(0)
		{
			memset(sVer, 0, sizeof sVer);
			strcpy(sVer, "LcAsm_00.01");
		}
	};

	struct AseTrack
	{
		INT		nF;										// Frame
		FLOAT	x;
		FLOAT	y;
		FLOAT	z;
		FLOAT	w;

		AseTrack() : nF(0), x(0), y(0), z(0), w(0){}
		AseTrack(INT F,FLOAT X,FLOAT Y,FLOAT Z,FLOAT W):nF(F),x(X),y(Y),z(Z),w(W){}
	};

	struct AseGeo
	{
		char		sNodeCur[32];						// Current Node Name
		char		sNodePrn[32];						// Parent Node Name
		INT			nNodePrn;							// Parent Index

		INT			nMtlRef	;							// Material Index

		// for ASE Parsing
		INT			iNumVtx	;							// Number of Vertex
		INT			iNumFce	;							// Number of Index

		INT			iNumTvtx;							// Number of Vertex
		INT			iNumTfce;							// Number of Index

		_AsePos*	pLstVtx	;							// Vertex List
//		_AseNor*	pLstNor	;							// Normal List
		_AseFce*	pLstFce	;							// Vertex Face List
		_AseTvtx*	pLstTvtx;							// UV List
		_AseFce*	pLstTfce;							// UV Face

		AseGeo*					pGeoPrn;
		AseTM					TmInf;					// Transform and Movement
		std::vector<AseTrack >	vRot;					// Rotation
		std::vector<AseTrack >	vTrs;					// Translation
		std::vector<AseTrack >	vScl;					// Scaling


		// Final Rendering Geometry Info
		LCXMATRIX	mtW		;							// World Matrix
		LCXMATRIX	mtL		;							// Local Matrix
		INT			m_iNix	;							// Number of Index
		INT			m_iNvx	;							// Number of Vertex
		AseIdx*		m_pIdx	;							// for indexed buffer
		void*		m_pVtx	;							// for vertex buffer
		DWORD		m_dFVF	;
		DWORD		m_dVtx	;							// Zero Stride

		AseGeo();
		~AseGeo();
	};

protected:
	AseScene	m_Scene		;
	INT			m_nMtl		;
	AseMtl*		m_pMtl		;
	INT			m_nGeo		;
	AseGeo*		m_pGeo		;

public:
	CLcAse();
	virtual ~CLcAse();

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		SetAttrib(char* sCmd, void* pData);
	virtual INT		GetAttrib(char* sCmd, void* pData);

public:
	void*	GetDevice()			{	return m_pDev;	}

	const AseScene* GetHeader() const{	return &m_Scene;}
	INT		GetNumMtl()			{	return m_nMtl;	}
	AseMtl*	GetMtrl()	 const	{	return m_pMtl;	}

	INT		GetNumGeo()			{	return m_nGeo;	}
	AseGeo*	GetGeometry() const	{	return m_pGeo;	}
	INT		GetAniTrack(void* mtA, INT nGeo, FLOAT dFrame);

protected:
	void	Confirm();

	INT		GetNumVtx(INT nGeo);
	INT		GetNumIdx(INT nGeo);

	void*	GetPtVtx(INT nGeo);
	void*	GetPtIdx(INT nGeo);

	BOOL	CompareAseKey(char* val, char* key);
	INT		Load();
	INT		ParseScene(FILE* fp);
	INT		ParseMaterial(FILE* fp);
	INT		ParseGeometry(FILE* fp);
	INT		ParseAnimation(FILE* fp);

	void	SetupRenderData();

protected:
	void	SaveToAsmBin();
	void	SaveToAsmTxt();
};

#endif

