// Implementation of the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>


#include "../_LcUtil/LcMath.h"

#include "ILcMdl.h"
#include "LcMdl.h"

#include "LcAse.h"
#include "LcAseInst.h"

#include "LcAseBin.h"
#include "LcAseBinInst.h"



INT LcMdl_CreateAse(char* sCmd
				 , ILcMdl** pData		// Output data
				 , void* pDev			// Device
				 , void* sName			// Model File Name
				 , void* pOrigin		// Original ILcMdl Pointer for Clone Creating
				 , void* p4				// Not Use
				 , void* p5				// Not Use
				 )
{
	(*pData) = NULL;

	char		Ext[_MAX_EXT]={0};
	const char*	sFile = NULL;
	char*		p  = NULL;

	ILcMdl*		pObj = NULL;

	if(sName)
		sFile = (char*)sName;

	else
	{
		ILcMdl* pOrg = (ILcMdl*)pOrigin;
		sFile  = pOrg->GetName();
	}

	p  = (char*)strrchr(sFile, '.');

	if(!p)
		return -1;

	strcpy(Ext, p+1);


	if(0==_stricmp(Ext, "ase") && NULL == pOrigin)
	{
		pObj = new CLcAse;

		if(FAILED(pObj->Create(pDev, sName)))
		{
			delete pObj;
			return -1;
		}
	}

	else if(0==_stricmp(Ext, "ase") && NULL != pOrigin)
	{
		pObj= new CLcAseInst;

		if(FAILED(pObj->Create(pDev, sName, pOrigin)))
		{
			delete pObj;
			return -1;
		}
	}
	
	else if(0==_stricmp(Ext, "asb") && NULL == pOrigin)
	{
		pObj= new CLcAseB;

		if(FAILED(pObj->Create(pDev, sName)))
		{
			delete pObj;
			return -1;
		}
	}
	else if(0==_stricmp(Ext, "asb") && NULL != pOrigin)
	{
		pObj= new CLcAseBInst;

		if(FAILED(pObj->Create(pDev, sName, pOrigin)))
		{
			delete pObj;
			return -1;
		}
	}


	*pData = pObj;
	
	return 0;
}