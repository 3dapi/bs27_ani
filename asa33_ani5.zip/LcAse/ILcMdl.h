// Interface for the ILcMdl class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILcMdl_H_
#define _ILcMdl_H_


struct ILcMdl
{
	virtual ~ILcMdl(){};

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;

	virtual	INT		FrameMove()=0;
	virtual void	Render()=0;

	virtual INT		SetAttrib(char* sCmd, void* pData)=0;
	virtual INT		GetAttrib(char* sCmd, void* pData)=0;

	virtual const char*	const GetName() const=0;
};


INT LcMdl_CreateAse(char* sCmd
				 , ILcMdl** pData		// Output data
				 , void* pDev			// Device
				 , void* sName	= NULL	// Model File Name
				 , void* pOrigin= NULL	// Original ILcMdl Pointer for Clone Creating
				 , void* p4=NULL		// Not Use
				 , void* p5=NULL		// Not Use
				 );

#endif

