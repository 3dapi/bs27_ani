// Implementation of the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>


#include "ILcMdl.h"
#include "LcAse.h"


#define MAX_PARSE_LINE	512


void LnStr_Trim(char* sBuf);
void LnStr_Quot(char* sDst, const char* sSrc);



CLcAse::AseGeo::AseGeo()
{
	nMtlRef = -1;
	iNumVtx = 0;
	iNumFce = 0;
	iNumTvtx= 0;
	iNumTfce = 0;

	pLstVtx = NULL;
	pLstNor	= NULL;
	pLstFce = NULL;

	pLstTvtx= NULL;
	pLstTfce= NULL;

	memset(sNodeCur, 0, sizeof sNodeCur);
	memset(sNodePrn, 0, sizeof sNodePrn);

	nNodePrn= -1;
	pGeoPrn	= NULL;
	m_iNix	= 0;
	m_iNvx	= 0;
	m_pIdx	= NULL;
	m_pVtx	= NULL;
	m_dFVF	= 0;
	m_dVtx	= 0;
}

CLcAse::AseGeo::~AseGeo()
{
	if(m_pIdx)
	{
		delete [] m_pIdx ;
		m_pIdx = NULL	;
	}

	if(m_pVtx)
	{
		if(m_dFVF == (DWORD)AseVtx::FVF)
		{
			AseVtx* pVtx = (AseVtx*)m_pVtx;
			delete [] pVtx;
		}

		if(m_dFVF == (DWORD)AseVtxN::FVF)
		{
			AseVtxN* pVtx = (AseVtxN*)m_pVtx;
			delete [] pVtx;
		}

		else if(m_dFVF == (DWORD)AseVtxUV::FVF)
		{
			AseVtxUV* pVtx = (AseVtxUV*)m_pVtx;
			delete [] pVtx;
		}

		else if(m_dFVF == (DWORD)AseVtxNUV::FVF)
		{
			AseVtxNUV* pVtx = (AseVtxNUV*)m_pVtx;
			delete [] pVtx;
		}

		m_pVtx = NULL;
	}

	nNodePrn= -1;
	pGeoPrn	= NULL;
	m_iNix	= 0;	m_iNvx	= 0;
	m_dFVF	= 0;	m_dVtx	= 0;
}


CLcAse::CLcAse()
{
	m_nMtl		= 0;
	m_pMtl		= NULL;

	m_nGeo		= 0;
	m_pGeo		= NULL;

	m_pDev	= NULL;

	m_nGeo	= NULL;
	m_pGeo	= NULL;


	m_nFrmF	= 0;
	m_nFrmL	= 0;
	m_nFrmS	= 0;
	m_nFrmT	= 0;

	m_dFrmCur = 0;
	m_dTimeCur= 0;
}

CLcAse::~CLcAse()
{
	Destroy();
}


INT CLcAse::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev	= (LPDIRECT3DDEVICE9)p1;
	strcpy(m_sFile, (char*)p2);


	if(FAILED(Load()))
		return -1;

	SetupRenderData();

	Confirm();

	this->GetAniFrameInf(&m_nFrmF, &m_nFrmL, &m_nFrmS, &m_nFrmT);


	// for Test...
	FLOAT	fRand = FLOAT(rand()%1000);

	m_dTimeCur = fRand/100.f;

	return 0;
}


void CLcAse::Destroy()
{
	m_nMtl	= 0;
	m_nGeo	= 0;

	if(m_pGeo)
	{
		delete [] m_pGeo;
		m_pGeo = NULL;
	}

	if(m_pMtl)
	{
		delete [] m_pMtl;
		m_pMtl = NULL;
	}

}






INT CLcAse::FrameMove()
{
	INT		i = 0;
	INT		nFrame	=0;

	// Frame = FrameSpeed * Time;
	m_dFrmCur = m_nFrmS * m_dTimeCur;

	nFrame	= INT(m_dFrmCur);

	if(nFrame>= m_nFrmL)
	{
		// ������ �ð��� ����ð����� �����Ѵ�.
		m_dTimeCur = m_dFrmCur - nFrame;
	}

	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*		pGeo = &m_pGeo[i];

		this->GetAniTrack(&pGeo->mtL, i, (FLOAT)m_dFrmCur);

		// �θ��� ���� ����� ���� �ڽ��� ���� ����� �ϼ��Ѵ�.
		D3DXMATRIX	mtPrn;
		D3DXMatrixIdentity(&mtPrn);

		if(0 <= pGeo->nNodePrn)
			mtPrn	= pGeo->pGeoPrn->mtW;

		pGeo->mtW = pGeo->mtL * mtPrn;

		INT c;
		c=0;
	}


	return 0;
}




void CLcAse::Render()
{
	if(!m_pGeo)
		return;

	INT	i=0;

	D3DXMATRIX	mtI;
	D3DXMatrixIdentity(&mtI);


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);


	// Texture�� ���� �κ�
	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*		pGeo = &m_pGeo[i];

		if(NULL == pGeo->m_pVtx)
			continue;

		LPDIRECT3DTEXTURE9	pTx=NULL;

		if(pGeo->nMtlRef>=0)
			pTx = m_pMtl[pGeo->nMtlRef].pTex;

//		if(NULL == pTx)
//			continue;


		m_pDev->SetTransform(D3DTS_WORLD, &(pGeo->mtW));
		m_pDev->SetFVF(pGeo->m_dFVF);
		m_pDev->SetTexture(0, pTx);

		m_pDev->DrawIndexedPrimitiveUP(
									D3DPT_TRIANGLELIST
									, 0						// Minimum Vertex Index
									, pGeo->m_iNvx			// Number vertex indices
									, pGeo->m_iNix			// Primitive Count
									, pGeo->m_pIdx			// IndexData pointer
									, D3DFMT_INDEX16		// Index Data format
									, pGeo->m_pVtx			// Vetex stream zero data
									, pGeo->m_dVtx			// Vertex Stream Zero Stride
									);
	}


	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);					// �ٽ� Solid
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
}


INT CLcAse::SetVal(char* sCmd, void* pData)
{
	if( 0 ==_stricmp("Advance Time", sCmd))
	{
		float	fElapsedTime = *((float*)pData);

		m_dTimeCur += fElapsedTime;

		return 0;
	}

	else if( 0 ==_stricmp("World Matrix", sCmd))
	{
		D3DXMATRIX* pTM = (D3DXMATRIX*)pData;

		m_mtWld	= *pTM;
		return 0;
	}


	return -1;
}


INT CLcAse::GetVal(char* sCmd, void* v)
{
	return -1;
}


INT CLcAse::GetNumVtx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];

	return pGeo->m_iNvx;
}

INT CLcAse::GetNumIdx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];

	return pGeo->m_iNix;
}

void*  CLcAse::GetPtVtx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];

	return pGeo->m_pVtx;
}

void*  CLcAse::GetPtIdx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];

	return pGeo->m_pIdx;
}


void CLcAse::GetAniFrameInf(INT* nFrmFirst, INT* nFrmLast, INT* nFrmSpeed, INT* nFrmTick)
{
	*nFrmFirst	= m_AseScene.nFrmF;
	*nFrmLast	= m_AseScene.nFrmL;
	*nFrmSpeed	= m_AseScene.nFrmS;
	*nFrmTick	= m_AseScene.nFrmT;
}


INT CLcAse::GetAniTrack(void* mtOut, INT nGeo, FLOAT nFrame)
{
	INT			i=0;
	D3DXMATRIX	mtA(1,0,0,0,   0,1,0,0,   0,0,1,0,   0,0,0,1);

	AseGeo*		pGeo	= &m_pGeo[nGeo];
	INT			iSizeR = pGeo->vRot.size();
	INT			iSizeP = pGeo->vTrs.size();

	D3DXQUATERNION* q1 = NULL;
	D3DXQUATERNION* q2 = NULL;
	D3DXVECTOR3* p1 = NULL;
	D3DXVECTOR3* p2 = NULL;

	if(iSizeR && pGeo->vRot[0].nF <=nFrame)
	{
		INT nFrm = pGeo->vRot[0].nF;
		INT nIdx;

		if(1 == iSizeR)
		{
			q1 = (D3DXQUATERNION*)&pGeo->vRot[0];
			D3DXMatrixRotationQuaternion(&mtA, q1);
		}

		else if(pGeo->vRot[iSizeR-1].nF <=nFrame)
		{
			q1 = (D3DXQUATERNION*)&pGeo->vRot[iSizeR-1];
			D3DXMatrixRotationQuaternion(&mtA, q1);
		}

		else
		{
			for(i=0; i<iSizeR-1; ++i)
			{
				if(pGeo->vRot[i].nF <=nFrame && nFrame <pGeo->vRot[i+1].nF)
				{
					D3DXQUATERNION q;

					q1 = (D3DXQUATERNION*)&pGeo->vRot[i];
					q2 = (D3DXQUATERNION*)&pGeo->vRot[i+1];

					FLOAT	w = FLOAT(nFrame - pGeo->vRot[i].nF)/(pGeo->vRot[i+1].nF- pGeo->vRot[i].nF);

					//q = *q1  + w * (*q2-*q1);
					D3DXQuaternionSlerp(&q, q1, q2, w);

					D3DXMatrixRotationQuaternion(&mtA, &q);
					break;
				}
			}
		}
	}

	else
	{
		mtA = pGeo->TmInf.mtL;
	}


	if(iSizeP && pGeo->vTrs[0].nF <=nFrame)
	{
		if(1 == iSizeP)
		{
			p1 = (D3DXVECTOR3*)&pGeo->vTrs[0];

			mtA._41 = p1->x;
			mtA._42 = p1->y;
			mtA._43 = p1->z;
		}
		else if(pGeo->vTrs[iSizeP-1].nF <=nFrame)
		{
			p1 = (D3DXVECTOR3*)&pGeo->vTrs[iSizeP-1];

			mtA._41 = p1->x;
			mtA._42 = p1->y;
			mtA._43 = p1->z;
		}
		else
		{
			for(i=0; i<iSizeP-1; ++i)
			{
				if(pGeo->vTrs[i].nF <=nFrame && nFrame <pGeo->vTrs[i+1].nF)
				{
					D3DXVECTOR3 p;

					p1 = (D3DXVECTOR3*)&pGeo->vTrs[i  ];
					p2 = (D3DXVECTOR3*)&pGeo->vTrs[i+1];

					FLOAT	w = FLOAT(nFrame- pGeo->vTrs[i].nF)/(pGeo->vTrs[i+1].nF- pGeo->vTrs[i].nF);

					p = *p1  + w * (*p2 - *p1);
					mtA._41 = p.x;	mtA._42 = p.y;	mtA._43 = p.z;
					break;
				}
			}
		}
	}
	else
	{
		mtA._41 = pGeo->TmInf.mtL._41;
		mtA._42 = pGeo->TmInf.mtL._42;
		mtA._43 = pGeo->TmInf.mtL._43;
	}


	*((D3DXMATRIX*) mtOut) = mtA;

	return 0;
}





enum	EAseKey
{
	SCENE,
	FRAME_FIRST,
	FRAME_LAST,
	FRAME_SPEED,
	FRAME_TICK,

	MTRL_LST	,
	MTRL_CNT	,
	MTRL_INF	,

	MTRL_MAPDIF	,
	MTRL_TEXDIF	,

	GEOOBJECT	,

	NODE_CUR	,
	NODE_PRN	,

	MTRL_REF	,

	NODE_TM		,
	TM_ROW0		,
	TM_ROW1		,
	TM_ROW2		,
	TM_ROW3		,
	TM_POS		,
	TM_ROT		,
	TM_RTA		,
	TM_SCL		,

	MESH_INFOS ,
	MESH_NUMVTX,
	MESH_NUMFCE,
	MESH_VTXLST,
	MESH_VTXREC,
	MESH_FCELST,
	MESH_FCEREC,

	MESH_NUMTVTX,
	MESH_TVTXLST,
	MESH_TVTXREC,

	MESH_NUMTFCE,
	MESH_TFCELST,
	MESH_TFCEREC,

	MESH_NORMAL,
	MESH_FCENRL,

	TM_ANIMATION,
	ROT_TRACK	,
	ROT_SAMPLE	,
	SCALE_TRACK	,
	SCALE_SAMPLE,
	POS_TRACK	,
	POS_SAMPLE	,

	ROT_TCB		,
	ROT_TCB_KEY	,
};



// Parsing Keyword
CLcAse::_AseKey Keywords[] =
{
	"*SCENE {"				,	// SCENE
	"*SCENE_FIRSTFRAME"		,	// FRAME_FIRST
	"*SCENE_LASTFRAME"		,	// FRAME_LAST
	"*SCENE_FRAMESPEED"		,	// FRAME_SPEED
	"*SCENE_TICKSPERFRAME"	,	// FRAME_TICK

	"*MATERIAL_LIST {"		,	// MTRL_LST
	"*MATERIAL_COUNT"		,	// MTRL_CNT
	"*MATERIAL "			,	// MTRL_INF

	"*MAP_DIFFUSE {"		,	// MTRL_MAPDIF
	"*BITMAP"				,	// MTRL_TEXDIF

	"*GEOMOBJECT {"			,	// GEOOBJECT

	"*NODE_NAME"			,	// NODE_CUR
	"*NODE_PARENT"			,	// NODE_PRN

	"*MATERIAL_REF"			,	// MTRL_REF

	"*NODE_TM {"			,	// NODE_TM
	"*TM_ROW0"				,	// TM_ROW0
	"*TM_ROW1"				,	// TM_ROW1
	"*TM_ROW2"				,	// TM_ROW2
	"*TM_ROW3"				,	// TM_ROW3
	"*TM_POS"				,	// TM_POS
	"*TM_ROTAXIS"			,	// TM_ROT
	"*TM_ROTANGLE"			,	// TM_RTA
	"*TM_SCALE"				,	// TM_SCL

	"*MESH {"				,	// MESH_INFOS
	"*MESH_NUMVERTEX"		,	// MESH_NUMVTX
	"*MESH_NUMFACES"		,	// MESH_NUMFCE
	"*MESH_VERTEX_LIST {"	,	// MESH_VTXLST
	"*MESH_VERTEX"			,	// MESH_VTXREC
	"*MESH_FACE_LIST {"		,	// MESH_FCELST
	"*MESH_FACE"			,	// MESH_FCEREC

	"*MESH_NUMTVERTEX"		,	// MESH_NUMTVTX
	"*MESH_TVERTLIST {"		,	// MESH_TVTXLST
	"*MESH_TVERT"			,	// MESH_TVTXREC

	"*MESH_NUMTVFACES"		,	// MESH_NUMTFCE
	"*MESH_TFACELIST {"		,	// MESH_TFCELST
	"*MESH_TFACE"			,	// MESH_TFCEREC

	"*MESH_NORMALS {"		,	// MESH_NORMAL
	"*MESH_FACENORMAL"		,	// MESH_FCENRL

	"*TM_ANIMATION {"		,	// TM_ANIMATION
	"*CONTROL_ROT_TRACK {"	,	// ROT_TRACK
	"*CONTROL_ROT_SAMPLE"	,	// ROT_SAMPLE
	"*CONTROL_SCALE_TRACK {",	// SCALE_TRACK
	"*CONTROL_SCALE_SAMPLE"	,	// SCALE_SAMPLE
	"*CONTROL_POS_TRACK {"	,	// POS_TRACK
	"*CONTROL_POS_SAMPLE"	,	// POS_SAMPLE

	"*CONTROL_ROT_TCB {"	,	// ROT_TCB
	"*CONTROL_TCB_ROT_KEY"	,	// ROT_TCB_KEY
};




BOOL CLcAse::CompareAseKey(char* val, char* key)
{
	return (0 == _strnicmp(val, key, strlen(key) ) ) ? 1: 0;
}



INT CLcAse::Load()
{
	FILE*	fp;

	fp = fopen(m_sFile, "rt");

	if(NULL == fp)
		return -1;


	ParseScene(fp);
	ParseMaterial(fp);
	ParseGeometry(fp);
	ParseAnimation(fp);

	fclose(fp);

	return 0;
}


INT CLcAse::ParseScene(FILE* fp)
{
	// Scene�Ľ�
	char	sLine[MAX_PARSE_LINE];

	while(!feof(fp))
	{
		fgets(sLine, MAX_PARSE_LINE, fp);
		LnStr_Trim(sLine);

		if(CompareAseKey(sLine, Keywords[SCENE]) )
		{
			while(!feof(fp))
			{
				fgets(sLine, MAX_PARSE_LINE, fp);
				LnStr_Trim(sLine);

				if('}' == sLine[0])
				{
					return 0;
//					break;
				}


				if(CompareAseKey(sLine, Keywords[FRAME_FIRST]) )
				{
					INT		nFirst;
					sscanf(sLine, "%*s %d", &nFirst);
					m_AseScene.nFrmF = nFirst;
				}

				if(CompareAseKey(sLine, Keywords[FRAME_LAST]) )
				{
					INT		nLast;
					sscanf(sLine, "%*s %d", &nLast);
					m_AseScene.nFrmL = nLast;
				}

				if(CompareAseKey(sLine, Keywords[FRAME_SPEED]) )
				{
					INT		nSpeed;
					sscanf(sLine, "%*s %d", &nSpeed);
					m_AseScene.nFrmS = nSpeed;
				}

				if(CompareAseKey(sLine, Keywords[FRAME_TICK]) )
				{
					INT		nTick;
					sscanf(sLine, "%*s %d", &nTick);
					m_AseScene.nFrmT = nTick;
				}

			}
		}

	}

	return 0;
}

INT	CLcAse::ParseMaterial(FILE* fp)
{
	// Material�Ľ�


	char	sLine[MAX_PARSE_LINE];


	// ���� �����͸� ó������ �ű��.
	fseek(fp, 0, SEEK_SET);


	// ��Ƽ���� ���ڸ� ����.
	m_nMtl	= 0;


	while(!feof(fp))
	{
		fgets(sLine, MAX_PARSE_LINE, fp);
		LnStr_Trim(sLine);

		if(CompareAseKey(sLine, Keywords[MTRL_LST]) )
		{
			while(!feof(fp))
			{
				fgets(sLine, MAX_PARSE_LINE, fp);
				LnStr_Trim(sLine);

				if('}' == sLine[0])
					break;

				if(CompareAseKey(sLine, Keywords[MTRL_CNT]) )
				{
					INT		iNmtl;
					sscanf(sLine, "%*s %d", &iNmtl);
					m_nMtl = iNmtl;

					if(m_nMtl>0)
						m_pMtl  = new CLcAse::AseMtl[m_nMtl];
				}

				if(CompareAseKey(sLine, Keywords[MTRL_INF]) )
				{
					INT	nMtl=-1;
					sscanf(sLine, "%*s %d", &nMtl);

					while(!feof(fp))
					{
						fgets(sLine, MAX_PARSE_LINE, fp);
						LnStr_Trim(sLine);

						if('}' == sLine[0])
							break;

						if(CompareAseKey(sLine, Keywords[MTRL_MAPDIF]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LnStr_Trim(sLine);

								if('}' == sLine[0])
									break;

								if(CompareAseKey(sLine, Keywords[MTRL_TEXDIF]) )
								{
									char	sFile[512];
									LnStr_Quot(sFile, sLine);

									char sTx[_MAX_FNAME]={0};
									char dir[_MAX_DIR]={0};
									char ext[_MAX_EXT];

									_splitpath (sFile, NULL, dir, sTx, ext);

									sprintf(m_pMtl[nMtl].sTex, "%s%s", sTx, ext);
								}

							}// while
						}// if

					}// while
				}// if


			}// while
		}//if
	}// while

	return 0;
}


INT CLcAse::ParseGeometry(FILE* fp)
{
	// Scene �Ľ�
	char	sLine[MAX_PARSE_LINE];


	// ���� �����͸� ó������ �ű��.
	fseek(fp, 0, SEEK_SET);


	//Geometry�� ���ڸ� ����.
	m_nGeo	= 0;

	while(!feof(fp))
	{
		fgets(sLine, MAX_PARSE_LINE, fp);
		LnStr_Trim(sLine);

		if(CompareAseKey(sLine, Keywords[GEOOBJECT]) )
			++m_nGeo;
	}

	if(0==m_nGeo)
		return -1;

	// ���� �����͸� ó������ �ű��.
	fseek(fp, 0, SEEK_SET);


	m_pGeo = new AseGeo[m_nGeo];
	INT	nGeoIdx = -1;

	while(!feof(fp))
	{
		fgets(sLine, MAX_PARSE_LINE, fp);
		LnStr_Trim(sLine);


		if(CompareAseKey(sLine, Keywords[GEOOBJECT]) )
		{
			++nGeoIdx;
			AseGeo* pGeo = &m_pGeo[nGeoIdx];

			while(!feof(fp))
			{
				fgets(sLine, MAX_PARSE_LINE, fp);
				LnStr_Trim(sLine);

				if('}' == sLine[0])
					break;


				if(CompareAseKey(sLine, Keywords[MTRL_REF]) )
				{
					INT		nMtl;
					sscanf(sLine, "%*s %d", &nMtl);
					pGeo->nMtlRef = nMtl;
				}

				if(CompareAseKey(sLine, Keywords[NODE_CUR]) )
				{
					char	sName[64];
					LnStr_Quot(sName, sLine);
					strcpy(pGeo->sNodeCur, sName);
				}

				if(CompareAseKey(sLine, Keywords[NODE_PRN]) )
				{
					char	sName[64];
					LnStr_Quot(sName, sLine);
					strcpy(pGeo->sNodePrn, sName);
				}


				if(CompareAseKey(sLine, Keywords[NODE_TM]) )
				{
					// Node TM
					while(!feof(fp))
					{
						fgets(sLine, MAX_PARSE_LINE, fp);
						LnStr_Trim(sLine);

						if('}' == sLine[0])
							break;


						if(CompareAseKey(sLine, Keywords[TM_ROW0]) )
						{
							FLOAT	x=0.F, y=0.F, z=0.F, w=0.F;
							sscanf(sLine, "%*s %f %f %f", &x, &y, &z);

							pGeo->TmInf.mtW._11  = x;
							pGeo->TmInf.mtW._12  = z;
							pGeo->TmInf.mtW._13  = y;
							pGeo->TmInf.mtW._14  = w;
						}

						if(CompareAseKey(sLine, Keywords[TM_ROW1]) )
						{
							FLOAT	x=0.F, y=0.F, z=0.F, w=0.F;
							sscanf(sLine, "%*s %f %f %f", &x, &y, &z);

							pGeo->TmInf.mtW._31  = x;
							pGeo->TmInf.mtW._32  = z;
							pGeo->TmInf.mtW._33  = y;
							pGeo->TmInf.mtW._34  = w;
						}

						if(CompareAseKey(sLine, Keywords[TM_ROW2]) )
						{
							FLOAT	x=0.F, y=0.F, z=0.F, w=0.F;
							sscanf(sLine, "%*s %f %f %f", &x, &y, &z);

							pGeo->TmInf.mtW._21  = x;
							pGeo->TmInf.mtW._22  = z;
							pGeo->TmInf.mtW._23  = y;
							pGeo->TmInf.mtW._24  = w;
						}

						if(CompareAseKey(sLine, Keywords[TM_ROW3]) )
						{
							FLOAT	x=0.F, y=0.F, z=0.F;
							FLOAT	w=1.F;
							sscanf(sLine, "%*s %f %f %f", &x, &y, &z);

							pGeo->TmInf.mtW._41  = x;
							pGeo->TmInf.mtW._42  = z;
							pGeo->TmInf.mtW._43  = y;
							pGeo->TmInf.mtW._44  = w;
						}

						if(CompareAseKey(sLine, Keywords[TM_POS]) )
						{
							FLOAT	x=0.F, y=0.F, z=0.F;
							sscanf(sLine, "%*s %f %f %f", &x, &y, &z);

							pGeo->TmInf.Px  = x;
							pGeo->TmInf.Py  = z;
							pGeo->TmInf.Pz  = y;
						}


						if(CompareAseKey(sLine, Keywords[TM_ROT]) )
						{
							FLOAT	x=0.F, y=0.F, z=0.F;
							sscanf(sLine, "%*s %f %f %f", &x, &y, &z);

							pGeo->TmInf.Rx  = x;
							pGeo->TmInf.Ry  = z;
							pGeo->TmInf.Rz  = y;
						}

						if(CompareAseKey(sLine, Keywords[TM_RTA]) )
						{
							FLOAT	w=0.F;
							sscanf(sLine, "%*s %f", &w);

							pGeo->TmInf.Rw  = w;
						}

						if(CompareAseKey(sLine, Keywords[TM_SCL]) )
						{
							FLOAT	x=0.F, y=0.F, z=0.F;
							sscanf(sLine, "%*s %f %f %f", &x, &y, &z);

							pGeo->TmInf.Sx  = x;
							pGeo->TmInf.Sy  = z;
							pGeo->TmInf.Sz  = y;
						}

					}// while NODE_TM
				}


				if(CompareAseKey(sLine, Keywords[MESH_INFOS]) )
				{
					while(!feof(fp))
					{
						fgets(sLine, MAX_PARSE_LINE, fp);
						LnStr_Trim(sLine);

						if('}' == sLine[0])
							break;

						if(CompareAseKey(sLine, Keywords[MESH_NUMVTX]) )
						{
							INT		iNVx;
							sscanf(sLine, "%*s %d", &iNVx);

							pGeo->iNumVtx = iNVx;

							if(iNVx>0)
								pGeo->pLstVtx = new CLcAse::_AsePos[iNVx];
						}

						if(CompareAseKey(sLine, Keywords[MESH_NUMFCE]) )
						{
							INT		iNIx;
							sscanf(sLine, "%*s %d", &iNIx);

							pGeo->iNumFce = iNIx;

							if(iNIx>0)
								pGeo->pLstFce = new CLcAse::_AseFce[iNIx];
						}


						if(CompareAseKey(sLine, Keywords[MESH_VTXLST]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LnStr_Trim(sLine);

								if('}' == sLine[0])
									break;

								if(CompareAseKey(sLine, Keywords[MESH_VTXREC]) )
								{
									INT		nIdx=0;
									FLOAT	x=0.F, y=0.F, z=0.F;
									sscanf(sLine, "%*s %d %f %f %f", &nIdx, &x, &y, &z);

									pGeo->pLstVtx[nIdx].x = x;
									pGeo->pLstVtx[nIdx].y = z;
									pGeo->pLstVtx[nIdx].z = y;
								}

							}
						}

						if(CompareAseKey(sLine, Keywords[MESH_FCELST]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LnStr_Trim(sLine);

								if('}' == sLine[0])
									break;

								if(CompareAseKey(sLine, Keywords[MESH_FCEREC]) )
								{
									INT	nIdx=0, a=0, b=0, c=0;

//									           *MESH_FACE 0:   A:  0  B: 1  C:  2
									sscanf(sLine, "%*s    %d: %*s %d %*s %d %*s %d", &nIdx, &a, &b, &c);

									pGeo->pLstFce[nIdx].a = a;
									pGeo->pLstFce[nIdx].b = c;
									pGeo->pLstFce[nIdx].c = b;
								}

							}// while
						}// if == MESH_FACE_LIST


						if(CompareAseKey(sLine, Keywords[MESH_NUMTVTX]) )
						{
							INT		iNtvtx;
							sscanf(sLine, "%*s %d", &iNtvtx);
							pGeo->iNumTvtx = iNtvtx;
							pGeo->pLstTvtx = new CLcAse::_AseTvtx[iNtvtx];

						}// if == *MESH_NUMTVERTEX


						if(CompareAseKey(sLine, Keywords[MESH_TVTXLST]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LnStr_Trim(sLine);

								if('}' == sLine[0])
									break;

								if(CompareAseKey(sLine, Keywords[MESH_TVTXREC]) )
								{
									INT		nIdx=0;
									FLOAT	u=0.F, v=0.F, w=0.F;
									sscanf(sLine, "%*s %d %f %f %f", &nIdx, &u, &v, &w);

									pGeo->pLstTvtx[nIdx].u = u;
									pGeo->pLstTvtx[nIdx].v = 1.f-v;
									pGeo->pLstTvtx[nIdx].w = w;
								}


							}// while
						}// if == *MESH_TVERTLIST {


						if(CompareAseKey(sLine, Keywords[MESH_NUMTFCE]) )
						{
							INT		iNtfce;
							sscanf(sLine, "%*s %d", &iNtfce);
							pGeo->iNumTfce = iNtfce;
							pGeo->pLstTfce = new CLcAse::_AseFce[iNtfce];

						}// if == *MESH_NUMTVFACES


						if(CompareAseKey(sLine, Keywords[MESH_TFCELST]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LnStr_Trim(sLine);

								if('}' == sLine[0])
									break;

								if(CompareAseKey(sLine, Keywords[MESH_TFCEREC]) )
								{
									INT		nIdx=0;
									INT		a=0, b=0, c=0;

									sscanf(sLine, "%*s %d %d %d %d", &nIdx, &a, &b, &c);

									pGeo->pLstTfce[nIdx].a = a;
									pGeo->pLstTfce[nIdx].b = c;
									pGeo->pLstTfce[nIdx].c = b;
								}


							}// while
						}// if == *MESH_TFACELIST {


						if(CompareAseKey(sLine, Keywords[MESH_NORMAL]) )
						{
							pGeo->pLstNor = new CLcAse::_AseNor[pGeo->iNumVtx];

							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LnStr_Trim(sLine);

								if('}' == sLine[0])
									break;

							}// while
						}// if == *MESH_NORMALS {



					}// while
				}// if


				if(CompareAseKey(sLine, Keywords[TM_ANIMATION]) )
				{
					while(!feof(fp))
					{
						fgets(sLine, MAX_PARSE_LINE, fp);
						LnStr_Trim(sLine);

						if('}' == sLine[0])
							break;

						if(CompareAseKey(sLine, Keywords[ROT_TRACK]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LnStr_Trim(sLine);

								if('}' == sLine[0])
									break;

							}// while
						}// if == *CONTROL_ROT_TRACK {


						if(CompareAseKey(sLine, Keywords[POS_TRACK]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LnStr_Trim(sLine);

								if('}' == sLine[0])
									break;

							}// while
						}// if == *CONTROL_SCALE_TRACK {

						if(CompareAseKey(sLine, Keywords[SCALE_TRACK]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LnStr_Trim(sLine);

								if('}' == sLine[0])
									break;

							}// while
						}// if == *CONTROL_POS_TRACK {


						if(CompareAseKey(sLine, Keywords[ROT_TCB]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LnStr_Trim(sLine);

								if('}' == sLine[0])
									break;

							}// while
						}// if == *CONTROL_ROT_TCB {


					}// while
				}// if == *TM_ANIMATION {



			}// while
		}// if


	}// while

	return 0;
}


INT CLcAse::ParseAnimation(FILE* fp)
{
	// Scene �Ľ�
	char	sLine[MAX_PARSE_LINE];


	// ���� �����͸� ó������ �ű��.
	fseek(fp, 0, SEEK_SET);



	while(!feof(fp))
	{
		fgets(sLine, MAX_PARSE_LINE, fp);
		LnStr_Trim(sLine);

		// TM_ANIMATION
		if(CompareAseKey(sLine, Keywords[TM_ANIMATION]) )
		{
			AseGeo* pGeo = NULL;

			while(!feof(fp))
			{
				fgets(sLine, MAX_PARSE_LINE, fp);
				LnStr_Trim(sLine);

				if('}' == sLine[0])
					break;

				// NODE_NAME
				if(CompareAseKey(sLine, Keywords[NODE_CUR]) )
				{
					char	sName[64];
					LnStr_Quot(sName, sLine);

					// Node�� �̸��� ���� ������Ʈ���� ã�´�.
					for(INT i=0; i<m_nGeo; ++i)
					{
						AseGeo*	pGeoCur = &m_pGeo[i];

						if(0==_stricmp(pGeoCur->sNodeCur, sName))
						{
							pGeo = pGeoCur;
							break;
						}
					}


				}

				// CONTROL_POS_TRACK
				if(CompareAseKey(sLine, Keywords[POS_TRACK]) )
				{
					while(!feof(fp))
					{
						fgets(sLine, MAX_PARSE_LINE, fp);
						LnStr_Trim(sLine);

						if('}' == sLine[0])
							break;


						if(CompareAseKey(sLine, Keywords[POS_SAMPLE]) )
						{
							INT		nTrck;
							FLOAT	x=0.F, y=0.F, z=0.F;
							sscanf(sLine, "%*s %d %f %f %f", &nTrck, &x, &y, &z);

							nTrck /= m_AseScene.nFrmT;

							AseTrack	trck(nTrck, x, z, y, 0);
							pGeo->vTrs.push_back(trck);

						}// if

					}// while CONTROL_POS_TRACK
				}// if

				// CONTROL_ROT_TRACK
				if(CompareAseKey(sLine, Keywords[ROT_TRACK]) )
				{
					while(!feof(fp))
					{
						fgets(sLine, MAX_PARSE_LINE, fp);
						LnStr_Trim(sLine);

						if('}' == sLine[0])
							break;


						if(CompareAseKey(sLine, Keywords[ROT_SAMPLE]) )
						{
							D3DXQUATERNION	q1;

							INT		nTrck;
							FLOAT	x=0.F, y=0.F, z=0.F, w=0.F;
							sscanf(sLine, "%*s %d %f %f %f %f", &nTrck, &x, &y, &z, &w);

							nTrck /= m_AseScene.nFrmT;

							q1.x = sinf(w/2.f) * x;
							q1.z = sinf(w/2.f) * y;
							q1.y = sinf(w/2.f) * z;
							q1.w = cosf(w/2.f);

							INT iSize = pGeo->vRot.size();

							if(0==iSize)
							{
								AseTrack	trck(nTrck, q1.x, q1.y, q1.z, q1.w);
								pGeo->vRot.push_back(trck);
							}
							else
							{
								D3DXQUATERNION*	q2;
								D3DXQUATERNION	q3;

								q2 = (D3DXQUATERNION*)&pGeo->vRot[iSize-1];

								D3DXQuaternionMultiply(&q3, q2, &q1);

								AseTrack	trck(nTrck, q3.x, q3.y, q3.z, q3.w);
								pGeo->vRot.push_back( trck );
							}

						}// if

					}// while CONTROL_ROT_TRACK
				}// if


				// CONTROL_SCALE_TRACK
				if(CompareAseKey(sLine, Keywords[SCALE_TRACK]) )
				{
					while(!feof(fp))
					{
						fgets(sLine, MAX_PARSE_LINE, fp);
						LnStr_Trim(sLine);

						if('}' == sLine[0])
							break;


						if(CompareAseKey(sLine, Keywords[SCALE_SAMPLE]) )
						{
							INT		nTrck;
							FLOAT	x=0.F, y=0.F, z=0.F;
							sscanf(sLine, "%*s %d %f %f %f", &nTrck, &x, &y, &z);

							nTrck /= m_AseScene.nFrmT;

							AseTrack	trck(nTrck, x, z, y, 0);
							pGeo->vScl.push_back(trck);

						}// if

					}// while CONTROL_SCALE_TRACK
				}// if


			}// while
		}// if TM_ANIMATION


	}// while

	return 0;
}




void CLcAse::SetupRenderData()
{
	INT i=0;
	INT j=0;

	// TM Processing
	// TmLocal = TmWorld * TmWorld(parent)-1

	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*	pGeoCur = &m_pGeo[i];
		AseGeo*	pGeoPrn = NULL;

		// Find Parent
		for(j=0; j<m_nGeo; ++j)
		{
			AseGeo*	pGeoT = &m_pGeo[j];

			if(0==_stricmp(pGeoCur->sNodePrn, pGeoT->sNodeCur))
			{
				pGeoPrn			= pGeoT;

				pGeoCur->nNodePrn= j;			//Setup Parent Index
				pGeoCur->pGeoPrn= pGeoT;		//Setup Parent Pointer
				break;
			}
		}

		if(pGeoPrn)
		{
			D3DXMATRIX mtPrn = pGeoPrn->TmInf.mtW;
			D3DXMATRIX mtPrnI;
			D3DXMATRIX mtL;
			D3DXMatrixInverse(&mtPrnI, NULL, &mtPrn);

			pGeoCur->TmInf.mtL = pGeoCur->TmInf.mtW * mtPrnI;
		}
		else
		{
			pGeoCur->TmInf.mtL = pGeoCur->TmInf.mtW;
		}
	}

	// Vertex Inversion
	// v(local) = v(world)*TmWorld-1
	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*	pGeoCur = &m_pGeo[i];

		D3DXMATRIX mtWI;
		D3DXMatrixInverse(&mtWI, NULL, &pGeoCur->TmInf.mtW);

		INT		iNvtx = pGeoCur->iNumVtx;

		for(j=0; j<iNvtx; ++j)
		{
			D3DXVECTOR3 vcI = *((D3DXVECTOR3*)&(pGeoCur->pLstVtx[j]));
			D3DXVECTOR3 vcO;

			D3DXVec3TransformCoord(&vcO, &vcI, &mtWI);

			*((D3DXVECTOR3*)&(pGeoCur->pLstVtx[j])) = vcO;
		}
	}




	// Setup FVF
	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*	pGeo = &m_pGeo[i];
		INT		iTfce = pGeo->iNumTfce;
		INT		nMtrl = pGeo->nMtlRef;

		if(pGeo->pLstVtx)
			pGeo->m_dFVF = AseVtx::FVF;

		if(pGeo->pLstNor)
			pGeo->m_dFVF |= D3DFVF_NORMAL;

		if(iTfce >0 && nMtrl>=0)
			pGeo->m_dFVF |= D3DFVF_TEX1;
	}

	// Setup Stride
	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*	pGeo = &m_pGeo[i];

		if(pGeo->m_dFVF == (DWORD)AseVtx::FVF)
			pGeo->m_dVtx = sizeof(AseVtx);

		else if(pGeo->m_dFVF == (DWORD)AseVtxN::FVF)
			pGeo->m_dVtx = sizeof(AseVtxN);

		else if(pGeo->m_dFVF == (DWORD)AseVtxUV::FVF)
			pGeo->m_dVtx = sizeof(AseVtxUV);

		else if(pGeo->m_dFVF == (DWORD)AseVtxNUV::FVF)
			pGeo->m_dVtx = sizeof(AseVtxNUV);
	}


	// Setup Index Data and Vertex Number
	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*	pGeo = &m_pGeo[i];

		if(pGeo->m_dFVF == (DWORD)AseVtx::FVF || pGeo->m_dFVF == (DWORD)AseVtxN::FVF)
		{
			pGeo->m_iNvx	= pGeo->iNumVtx;	// ������ ��
			pGeo->m_iNix	= pGeo->iNumFce;
			pGeo->m_pIdx	= new AseIdx[pGeo->m_iNix];
			memcpy(pGeo->m_pIdx, pGeo->pLstFce, pGeo->m_iNix * sizeof(AseIdx));
		}
		else if(pGeo->m_dFVF == (DWORD)AseVtxUV::FVF || pGeo->m_dFVF == (DWORD)AseVtxNUV::FVF)
		{
			pGeo->m_iNvx	= pGeo->iNumTvtx;	// UV�� ��
			pGeo->m_iNix	= pGeo->iNumTfce;
			pGeo->m_pIdx	= new AseIdx[pGeo->m_iNix];
			memcpy(pGeo->m_pIdx, pGeo->pLstTfce, pGeo->m_iNix * sizeof(AseIdx));


			// �ε��� ����
			for(j=0; j<pGeo->m_iNix; ++j)
			{
				// ������ġ�� �ε���
				INT Va = pGeo->pLstFce[j].a;
				INT Vb = pGeo->pLstFce[j].b;
				INT Vc = pGeo->pLstFce[j].c;

				// UV�� �ε���
				INT Ta = pGeo->pLstTfce[j].a;
				INT Tb = pGeo->pLstTfce[j].b;
				INT Tc = pGeo->pLstTfce[j].c;

				// Tvtx�ε����� �ִ� ������ �ε����� ����
				pGeo->pLstTvtx[Ta].nT = Va;
				pGeo->pLstTvtx[Tb].nT = Vb;
				pGeo->pLstTvtx[Tc].nT = Vc;
			}
		}
	}


	// Setup Vertex Buffer
	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*	pGeo = &m_pGeo[i];

		if(pGeo->m_dFVF == (DWORD)AseVtx::FVF)
		{
			AseVtx* pVtx = new AseVtx[pGeo->m_iNvx];
			memcpy( pVtx, pGeo->pLstVtx, pGeo->m_iNvx * pGeo->m_dVtx);
			pGeo->m_pVtx = pVtx;
		}

		if(pGeo->m_dFVF == (DWORD)AseVtxN::FVF)
		{
			AseVtxN* pVtx = new AseVtxN[pGeo->m_iNvx];

			for(j=0; j<pGeo->m_iNvx; ++j)
			{
				pVtx[j].p.x = pGeo->pLstVtx[j].x;
				pVtx[j].p.y = pGeo->pLstVtx[j].y;
				pVtx[j].p.z = pGeo->pLstVtx[j].z;

				pVtx[j].n.x = pGeo->pLstNor[j].x;
				pVtx[j].n.y = pGeo->pLstNor[j].y;
				pVtx[j].n.z = pGeo->pLstNor[j].z;
			}

			pGeo->m_pVtx = pVtx;
		}

		else if(pGeo->m_dFVF == (DWORD)AseVtxUV::FVF)
		{
			AseVtxUV* pVtx = new AseVtxUV[pGeo->m_iNvx];

			// �ε����� ���� ���� ����
			for(j=0; j<pGeo->m_iNvx; ++j)
			{
				INT nT = pGeo->pLstTvtx[j].nT ;

				pVtx[j].p.x = pGeo->pLstVtx[nT].x;
				pVtx[j].p.y = pGeo->pLstVtx[nT].y;
				pVtx[j].p.z = pGeo->pLstVtx[nT].z;

				pVtx[j].u = pGeo->pLstTvtx[j].u;
				pVtx[j].v = pGeo->pLstTvtx[j].v;
			}

			pGeo->m_pVtx = pVtx;
		}

		else if(pGeo->m_dFVF == (DWORD)AseVtxNUV::FVF)
		{
			AseVtxNUV* pVtx = new AseVtxNUV[pGeo->m_iNvx];

			// �ε����� ���� ���� ����
			for(j=0; j<pGeo->m_iNvx; ++j)
			{
				INT nT = pGeo->pLstTvtx[j].nT ;

				pVtx[j].p.x = pGeo->pLstVtx[nT].x;
				pVtx[j].p.y = pGeo->pLstVtx[nT].y;
				pVtx[j].p.z = pGeo->pLstVtx[nT].z;

				pVtx[j].n.x = pGeo->pLstNor[nT].x;
				pVtx[j].n.y = pGeo->pLstNor[nT].y;
				pVtx[j].n.z = pGeo->pLstNor[nT].z;

				pVtx[j].u = pGeo->pLstTvtx[j].u;
				pVtx[j].v = pGeo->pLstTvtx[j].v;
			}

			pGeo->m_pVtx = pVtx;
		}
	}


	// Delete List Data
	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*	pGeo = &m_pGeo[i];

		if(pGeo->pLstVtx)		delete [] pGeo->pLstVtx;
		if(pGeo->pLstNor)		delete [] pGeo->pLstNor;
		if(pGeo->pLstFce)		delete [] pGeo->pLstFce;
		if(pGeo->pLstTvtx)		delete [] pGeo->pLstTvtx;
		if(pGeo->pLstTfce)		delete [] pGeo->pLstTfce;

		pGeo->iNumVtx	= 0;
		pGeo->iNumFce	= 0;

		pGeo->iNumTvtx	= 0;
		pGeo->iNumTfce	= 0;

		pGeo->pLstVtx	= NULL;
		pGeo->pLstNor	= NULL;
		pGeo->pLstFce	= NULL;
		pGeo->pLstTvtx	= NULL;
		pGeo->pLstTfce	= NULL;
	}



	// Setup Matrix
	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*		pGeo = &m_pGeo[i];
		pGeo->mtW = pGeo->TmInf.mtW;
		pGeo->mtL = pGeo->TmInf.mtL;
	}





	// Setup Texture
	for(i=0; i<m_nMtl; ++i)
	{
		AseMtl*		pMtl = &m_pMtl[i];

		char sFile[_MAX_PATH];

		DWORD		color		= 0x00FFFFFF;
		DWORD		Filter		= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR);
		DWORD		MipFilter	= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR);
		D3DFORMAT	d3dFormat	= D3DFMT_UNKNOWN;


		sprintf(sFile, "Model/%s", pMtl->sTex);

		if ( FAILED(D3DXCreateTextureFromFileEx(m_pDev
											, sFile
											, D3DX_DEFAULT
											, D3DX_DEFAULT
											, D3DX_DEFAULT
											, 0
											, d3dFormat
											, D3DPOOL_MANAGED
											, Filter
											, MipFilter
											, color
											, &pMtl->pImg
											, NULL
											, &pMtl->pTex
											)) )
		{
			MessageBox(GetActiveWindow(), "Cannot Read Model Texture", "Error", 0);
		}
	}

}




void CLcAse::Confirm()
{
	FILE*	fp;
	INT		i=0, j=0;


	char	sDst[260]={0};
	strcpy(sDst, m_sFile);
	char * p = strchr(sDst, '.');
	*p = '\0';
	strcat(p, ".txt");


	fp= fopen(sDst, "wt");
	if(NULL == fp)
		return;

//
//	fprintf(fp, "%s\n", Keywords[MTRL_LST]);
//	fprintf(fp, "	%s	%d\n", Keywords[MTRL_CNT], m_nMtl);
//
//	for(i=0; i<m_nMtl; ++i)
//	{
//		fprintf(fp, "	%s %d {\n", Keywords[MTRL_INF], i);
//		fprintf(fp, "		%s\n", Keywords[MTRL_MAPDIF]);
//
//		fprintf(fp, "			%s	\"%s\"\n", Keywords[MTRL_TEXDIF], m_pMtl[i].sTex);
//
//		fprintf(fp, "		}\n");
//		fprintf(fp, "	}\n\n");
//	}
//	fprintf(fp, "}\n\n");



	// Geometry
	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*	pGeo = &m_pGeo[i];

		fprintf(fp, "%s\n", Keywords[GEOOBJECT]);
		fprintf(fp, "	%s	\"%s\"\n", Keywords[NODE_CUR], pGeo->sNodeCur);
		fprintf(fp, "	%s	\"%s\"\n", Keywords[NODE_PRN], pGeo->sNodePrn);
//		fprintf(fp, "	%s\n", Keywords[MESH_INFOS]);
//
//		fprintf(fp, "		%s	%d\n", Keywords[MESH_NUMVTX], pGeo->iNumVtx);
//		fprintf(fp, "		%s	%d\n", Keywords[MESH_NUMFCE], pGeo->iNumFce);
//
//		fprintf(fp, "		%s\n"	, Keywords[MESH_VTXLST]);
//
//
//		INT iNumVtx = pGeo->iNumVtx;
//
//		for(j=0; j<iNumVtx; ++j)
//		fprintf(fp, "			%s	%f	%f	%f\n", Keywords[MESH_VTXREC]
//										, pGeo->pLstVtx[j].x
//										, pGeo->pLstVtx[j].y
//										, pGeo->pLstVtx[j].z);
//
//		fprintf(fp, "		}\n\n");
//
//		fprintf(fp, "		%s\n"	, Keywords[MESH_FCELST]);
//
//		INT iNumFce = pGeo->iNumFce;
//
//		for(j=0; j<iNumFce; ++j)
//		fprintf(fp, "			%s	%u	%u	%u\n", Keywords[MESH_FCEREC]
//										, pGeo->pLstFce[j].a
//										, pGeo->pLstFce[j].b
//										, pGeo->pLstFce[j].c);
//
//		fprintf(fp, "		}\n");
//
//		fprintf(fp, "	}\n");

		fprintf(fp, "}\n\n");
	}


	fclose(fp);
}




void LnStr_Trim(char* sBuf)
{
	INT iLen = 0;

	INT	i=0;
	INT iCnt=0;

	iLen = strlen(sBuf);

	if(iLen <1)
		return;


	// ���� \r \n����
	for(i=iLen-1; i>=0; --i)
	{
		char* p = sBuf + i;

		if( '\n' == *p || '\r' == *p)
		{
			*(sBuf + i) = '\0';
		}

		++iCnt;

		if(iCnt>2)
			break;
	}


	// ������ ���� ����
	iCnt = 0;
	iLen = strlen(sBuf);

	for(i=iLen-1; i>=0; --i)
	{
		char* p = sBuf + i;

		if( ' ' == *p || '\t' == *p)
			continue;

		*(sBuf + i+1) = '\0';
		break;
	}

	iLen = i+1 +1;

	// ������ ��������
	char sT[1024]={0};

	strncpy(sT, sBuf, iLen);

	for(i=0; i < iLen; ++i)
	{
		char* p = sT + i;

		if( ' ' == *p || '\t' == *p)
			continue;

		break;
	}

	strcpy(sBuf, sT+i);
}



void LnStr_Quot(char* sDst, const char* sSrc)
{
	INT iLen = strlen(sSrc);
	INT	nBgn  =-1;
	INT bStrt =0;
	INT iRead =0;

	char* p = (char*)sSrc;

	while( 0 != *p)
	{
		if( '\"' == *p && 0 == bStrt)
			bStrt = 1;

		else if( '\"' == *p && 1 == bStrt)
		{
			*(sDst + nBgn) = 0;
			break;
		}

		if(nBgn>=0 && 1== bStrt)
			*(sDst + nBgn) = *p;

		if(1== bStrt)
			++nBgn;

		++p;
	}
}
