// Interface for the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcAse_H_
#define _LcAse_H_


class CLcAse
{
protected:
	char	m_sFile[MAX_PATH];														// Model file
	INT		m_iNIx;																// Number of Index
	INT		m_iNVx;																// Number of Vertex

public:
	CLcAse();
	virtual ~CLcAse();

	virtual INT		Create(char* sFile);
	virtual void	Destroy();

protected:
	INT		Load();
	void	Confirm();
};

#endif

