// Implementation of the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>

#include "LcAse.h"


#define MAX_PARSE_LINE	512


void LcStr_Trim(char* sBuf)
{
	int iLen = 0;

	int	i=0;
	int iCnt=0;

	iLen = strlen(sBuf);

	if(iLen <1)
		return;


	// ���� \r \n����
	for(i=iLen-1; i>=0; --i)
	{
		char* p = sBuf + i;

		if( '\n' == *p || '\r' == *p)
		{
			*(sBuf + i) = '\0';
		}

		++iCnt;

		if(iCnt>2)
			break;
	}


	// ������ ���� ����
	iCnt = 0;
	iLen = strlen(sBuf);

	for(i=iLen-1; i>=0; --i)
	{
		char* p = sBuf + i;

		if( ' ' == *p || '\t' == *p)
			continue;

		*(sBuf + i+1) = '\0';
		break;
	}

	iLen = i+1 +1;

	// ������ ��������
	char sT[MAX_PARSE_LINE]={0};

	strncpy(sT, sBuf, iLen);

	for(i=0; i < iLen; ++i)
	{
		char* p = sT + i;

		if( ' ' == *p || '\t' == *p)
			continue;

		break;
	}

	strcpy(sBuf, sT+i);
}



void LcStr_Quot(char* sDst, const char* sSrc)
{
	int iLen = strlen(sSrc);
	int	nBgn  =-1;
	int bStrt =0;
	int iRead =0;

	char* p = (char*)sSrc;

	while( 0 != *p)
	{
		if( '\"' == *p && 0 == bStrt)
			bStrt = 1;

		else if( '\"' == *p && 1 == bStrt)
		{
			*(sDst + nBgn) = 0;
			break;
		}

		if(nBgn>=0 && 1== bStrt)
			*(sDst + nBgn) = *p;

		if(1== bStrt)
			++nBgn;

		++p;
	}
}




CLcAse::CLcAse()
{
}

CLcAse::~CLcAse()
{
	Destroy();
}


INT CLcAse::Create(char* sFile)
{
	strcpy(m_sFile, sFile);


	if(FAILED(Load()))
		return -1;

	Confirm();

	return 0;
}

void CLcAse::Destroy()
{
}


typedef char AseKey[64];	// String Keword

// Parsing Keyword
AseKey	Keywords[] =
{
	"*GEOMOBJECT {"			,	// 0
	"*NODE_NAME"			,	// 1
	"*NODE_TM {"			,	// 2
	"*MESH {"				,	// 3
	"*MESH_NUMVERTEX"		,	// 4
	"*MESH_NUMFACES"		,	// 5
	"*MESH_VERTEX_LIST {"	,	// 6
	"*MESH_VERTEX"			,	// 7
	"*MESH_FACE_LIST {"		,	// 8
	"*MESH_FACE"			,	// 9
};


BOOL CompareAseKey(char* val, char* key)
{
	return (0 == _strnicmp(val, key, strlen(key) ) ) ? 1: 0;
}


INT CLcAse::Load()
{
	FILE*	fp;
	char	sLine[MAX_PARSE_LINE];

	fp = fopen(m_sFile, "rt");



	if(NULL == fp)
		return -1;

	while(!feof(fp))
	{
		fgets(sLine, MAX_PARSE_LINE, fp);
		LcStr_Trim(sLine);


		if(CompareAseKey(sLine, Keywords[0]) )
		{
			while(!feof(fp))
			{
				fgets(sLine, MAX_PARSE_LINE, fp);
				LcStr_Trim(sLine);

				if('}' == sLine[0])
					break;

				if(CompareAseKey(sLine, Keywords[1]) )
				{
					char	sName[128];

//					sscanf(sLine, "%*s %s", sName1);
					LcStr_Quot(sName, sLine);
				}

				else if(CompareAseKey(sLine, Keywords[2]) )
				{
					while(!feof(fp))
					{
						fgets(sLine, MAX_PARSE_LINE, fp);
						LcStr_Trim(sLine);

						if('}' == sLine[0])
							break;
					}

				}

				else if(CompareAseKey(sLine, Keywords[3]) )
				{
					while(!feof(fp))
					{
						fgets(sLine, MAX_PARSE_LINE, fp);
						LcStr_Trim(sLine);

						if('}' == sLine[0])
							break;

						if(CompareAseKey(sLine, Keywords[4]) )
						{
							INT		iNVx;
							sscanf(sLine, "%*s %d", &iNVx);
							m_iNVx = iNVx;

						}

						if(CompareAseKey(sLine, Keywords[5]) )
						{
							INT		iNIx;
							sscanf(sLine, "%*s %d", &iNIx);
							m_iNIx = iNIx;

						}


						if(CompareAseKey(sLine, Keywords[6]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LcStr_Trim(sLine);

								if('}' == sLine[0])
									break;

								if(CompareAseKey(sLine, Keywords[7]) )
								{
									INT		nIdx=0;
									FLOAT	x=0.F, y=0.F, z=0.F;
									sscanf(sLine, "%*s %d %f %f %f", &nIdx, &x, &y, &z);
								}

							}
						}

						if(CompareAseKey(sLine, Keywords[8]) )
						{
							while(!feof(fp))
							{
								fgets(sLine, MAX_PARSE_LINE, fp);
								LcStr_Trim(sLine);

								if('}' == sLine[0])
									break;

								if(CompareAseKey(sLine, Keywords[9]) )
								{
									INT	nIdx=0, a=0, b=0, c=0;

//									           *MESH_FACE 0:   A:  0  B: 1  C:  2
									sscanf(sLine, "%*s    %d: %*s %d %*s %d %*s %d", &nIdx, &a, &b, &c);

								}

							}// while
						}// if

					}// while
				}// if



			}// while
		}// if


	}// while

	fclose(fp);

	return 0;
}

void CLcAse::Confirm()
{
	FILE*	fp;
	INT		i;


	char	sDst[260]={0};
	strcpy(sDst, m_sFile);
	char * p = strchr(sDst, '.');
	*p = '\0';
	strcat(p, ".txt");

	fp= fopen(sDst, "wt");
	if(NULL == fp)
		return;

	fprintf(fp, "Number of face %d\n", m_iNIx);
	fprintf(fp, "\n");

	for(i=0; i<m_iNIx;++i)
	{
//		fprintf(fp, "Face %3d    %3u %3u %3u\n", i, m_pIdx[i].a, m_pIdx[i].b, m_pIdx[i].c);
	}

	fprintf(fp, "\n");
	fprintf(fp, "Number of Vertex %d\n", m_iNVx);
	fprintf(fp, "\n");

	for(i=0; i<m_iNVx; ++i)
	{
//		fprintf(fp, "vertex %3d   %8.4f %8.4f %8.4f\n", i, m_pVtx[i].p.x, m_pVtx[i].p.y, m_pVtx[i].p.z);
	}

	fclose(fp);
}

