// Interface for the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcAse_H_
#define _LcAse_H_


class CLcAse
{
public:
	struct VtxIdx
	{
		union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

		VtxIdx() : a(0), b(1), c(2){}
		VtxIdx(WORD A, WORD B, WORD C) : a(A), b(B), c(C){}
		VtxIdx(WORD* r)					{	a = r[0]; b = r[1];	 c = r[2];	}
		operator WORD*()				{		return (WORD *) &a;			}
		operator const WORD* () const	{		return (CONST WORD *) &a;	}
	};

	struct VtxD
	{
		D3DXVECTOR3	p;
		DWORD		d;

		VtxD()								{	p.x=p.y=p.z=0.f;d=0xFFFFFFFF;	}
		VtxD(FLOAT X,FLOAT Y,FLOAT Z,DWORD D){	p.x=X; p.y=Y; p.z=Z; d=D;		}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE),};
	};

	typedef char AseKey[64];		// String Keword

	struct AseVtx
	{
		FLOAT x, y, z;
		AseVtx() : x(0), y(0), z(0){}
	};

	struct AseFce
	{
		WORD a, b, c;
		AseFce() : a(0), b(0), c(0){}
	};

	struct AseGeo
	{
		char	sNodeName[64];
		INT		iNumVtx;				// Number of Vertex
		INT		iNumFce;				// Number of Index

		AseVtx*	pLstVtx;
		AseFce*	pLstFce;

		AseGeo()
		{
			iNumVtx = 0;
			iNumFce = 0;
			pLstVtx = NULL;
			pLstFce = NULL;

			memset(sNodeName, 0, sizeof sNodeName);
		}

		~AseGeo()
		{
			if(pLstVtx)
			{
				delete [] pLstVtx;
				pLstVtx= NULL;
			}

			if(pLstFce)
			{
				delete [] pLstFce;
				pLstFce = NULL;
			}
		}
	};

protected:
	char		m_sFile[MAX_PATH];		// Model file

	INT			m_iNGeo		;
	AseGeo*		m_pGeo		;


	LPDIRECT3DDEVICE9	m_pDev;
	INT			m_iNIx		;			// Number of Index
	INT			m_iNVx		;			// Number of Vertex
	VtxIdx*		m_pIdx		;			// for indexed buffer
	VtxD*		m_pVtx		;			// for vertex buffer

public:
	CLcAse();
	virtual ~CLcAse();

	virtual INT		Create(LPDIRECT3DDEVICE9 pDev, char* sFile);
	virtual void	Destroy();

	virtual	INT		FrameMove();
	virtual void	Render();

protected:
	void	Confirm();
	INT		GetGeoNum();
	INT		GetVtxNum(INT nIdx);
	INT		GetIdxNum(INT nIdx);

	void*	GetVtx(INT nIdx);
	void*	GetIdx(INT nIdx);

protected:
	BOOL	CompareAseKey(char* val, char* key);
	INT		Load();

};

#endif

