// Implementation of the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>


#include "ILcMdl.h"
#include "LcAse.h"


INT LcAse_Create(char* sCmd
				 , ILcMdl** pData		// Output data
				 , void* pDev			// Device
				 , void* sName			// Model File Name
				 , void* pOriginal		// Original ILcMdl Pointer for Clone Creating
				 , void* p4				// Not Use
				 , void* p5				// Not Use
				 )
{
	*pData = NULL;

	CLcAse*	p= new CLcAse;

	if(FAILED(p->Create(pDev, sName)))
	{
		delete p;
		return -1;
	}

	*pData = p;
	return 0;
}