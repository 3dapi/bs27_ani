// Interface for the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcAse_H_
#define _LcAse_H_


#include <vector>


class CLcAse : public ILcMdl
{
public:
	struct AseFce
	{
		union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

		AseFce() : a(0), b(1), c(2){}
		AseFce(WORD A, WORD B, WORD C) : a(A), b(B), c(C){}
		AseFce(WORD* r)					{	a = r[0]; b = r[1];	 c = r[2];	}
		operator WORD*()				{		return (WORD *) &a;			}
		operator const WORD* () const	{		return (CONST WORD *) &a;	}
	};

	typedef char AseKey[64];		// String Keword

	struct AseMtl
	{
		char				sTex[MAX_PATH];
		D3DXIMAGE_INFO		pImg;
		LPDIRECT3DTEXTURE9	pTex;

		AseMtl()
		{
			memset(sTex, 0, sizeof sTex);
			pTex = NULL;
		}

		~AseMtl()
		{
			if(pTex)
			{
				pTex->Release();
				pTex	= NULL;
			}
		}
	};

	struct AseTvtx
	{
		INT		nVt;				// �迭���� ������ �ε���
		FLOAT	u, v, w;			// UVW��ǥ

		AseTvtx() :nVt(-1), u(0), v(0), w(0){}
	};

	struct AseVtx
	{
		FLOAT x, y, z;
		AseVtx() : x(0), y(0), z(0){}
		enum	{FVF = (D3DFVF_XYZ),};
	};

	struct AseVtxN
	{
		FLOAT	Px, Py, Pz;
		FLOAT	Nx, Ny, Nz;

		AseVtxN() : Px(0), Py(0), Pz(0), Nx(0), Ny(0), Nz(0){}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_NORMAL),};
	};

	struct AseVtxUV
	{
		FLOAT	Px, Py, Pz;
		FLOAT	u, v;

		AseVtxUV() : Px(0), Py(0), Pz(0), u(0),v(0){}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_TEX1),};
	};

	struct AseVtxNUV
	{
		FLOAT	Px, Py, Pz;
		FLOAT	Nx, Ny, Nz;
		FLOAT	u, v;

		AseVtxNUV() : Px(0), Py(0), Pz(0), Nx(0), Ny(0), Nz(0), u(0),v(0){}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1),};
	};

	struct AseTM
	{
		D3DXMATRIX	mtW;							// World Matrix
		D3DXMATRIX	mtL;							// Local Matirx

		FLOAT	Px, Py, Pz;
		FLOAT	Rx, Ry, Rz, Rw;
		FLOAT	Sx, Sy, Sz;

		AseTM() : Px(0), Py(0), Pz(0)
					, Rx(0), Ry(0), Rz(0), Rw(0)
					, Sx(0), Sy(0), Sz(0){}
	};


	struct AseScene
	{
		INT			nFrameFirst;							// First Frame
		INT			nFrameLast;								// Last Frame
		INT			nFrameSpeed;							// Frame Speed Per one scecond
		INT			nFrameTick;								// Tick per one Frame

		AseScene() : nFrameFirst(0), nFrameLast(0)
					, nFrameSpeed(0), nFrameTick(0){}
	};

	struct AseTrack
	{
		FLOAT	x, y, z, w;									// Animation value
		INT		nF;											// Frame Index

		AseTrack() : nF(0), x(0), y(0), z(0), w(0){}
		AseTrack(INT T,FLOAT X,FLOAT Y,FLOAT Z,FLOAT W): nF(T),x(X),y(Y),z(Z),w(W){}
	};

	struct AseTrackAni
	{
		char		sNodeCur[64];							// Current Node Name

		std::vector<AseTrack >	vRot;						// Rotation
		std::vector<AseTrack >	vTrs;						// Translation
		std::vector<AseTrack >	vScl;						// Scaling

		AseTrackAni()
		{
			memset(sNodeCur, 0, sizeof sNodeCur);
		}
	};

	struct AseGeo
	{
		char		sNodeCur[64];							// Current Node Name
		char		sNodePrn[64];							// Parent Node Name

		INT			nMtlRef;								// Material Index
		INT			iNumVtx;								// Number of Vertex
		INT			iNumFce;								// Number of Index

		INT			iNumTvtx;								// Number of Vertex
		INT			iNumTfce;								// Number of Index

		AseVtx*		pLstVtx;
		AseVtx*		pLstNor;
		AseFce*		pLstFce;

		AseTvtx*	pLstTvtx;
		AseFce*		pLstTfce;

		AseVtxN*	pVtxN;
		AseVtxUV*	pVtxUV;
		AseVtxNUV*	pVtxNUV;


		INT			iNix	;								// Number of Index
		INT			iNvx	;								// Number of Vertex
		AseFce*		pIdx	;								// for indexed buffer
		void*		pVtx	;								// for vertex buffer
		DWORD		dFVF	;								// D3DX FVF
		DWORD		dStrid	;								// Zero Stride

		AseGeo*		pGeoPrn	;								// Parent Node

		AseTM			TmInf;								// Transform and Movement
		AseTrackAni*	pTrckAni;							// Animation Track

		AseGeo()
		{
			nMtlRef = -1;
			iNumVtx = 0;
			iNumFce = 0;
			iNumTvtx= 0;
			iNumTfce = 0;

			pLstVtx = NULL;
			pLstNor	= NULL;
			pLstFce = NULL;

			pLstTvtx= NULL;
			pLstTfce= NULL;

			dFVF	= 0;
			dStrid	= 0;

			pVtxN	= NULL;
			pVtxUV	= NULL;
			pVtxNUV	= NULL;

			memset(sNodeCur, 0, sizeof sNodeCur);
			memset(sNodePrn, 0, sizeof sNodePrn);


			iNix	=0;
			iNvx	=0;
			pIdx	=NULL;
			pVtx	=NULL;
			dFVF	= 0;
			dStrid	= 0;

			pGeoPrn		= NULL;
			pTrckAni	= NULL;
		}

		~AseGeo()
		{
			if(pLstVtx)
			{
				delete [] pLstVtx;
				pLstVtx= NULL;
			}

			if(pLstNor)
			{
				delete [] pLstNor;
				pLstNor= NULL;
			}

			if(pLstFce)
			{
				delete [] pLstFce;
				pLstFce = NULL;
			}

			if(pLstTvtx)
			{
				delete [] pLstTvtx;
				pLstTvtx= NULL;
			}

			if(pLstTfce)
			{
				delete [] pLstTfce;
				pLstTfce = NULL;
			}

			if(pVtxN)
			{
				delete [] pVtxN;
				pVtxN = NULL;
			}

			if(pVtxUV)
			{
				delete [] pVtxUV;
				pVtxUV = NULL;
			}

			if(pVtxNUV)
			{
				delete [] pVtxNUV;
				pVtxNUV = NULL;
			}
		}
	};


protected:
	LPDIRECT3DDEVICE9	m_pDev	;

	char		m_sFile[MAX_PATH];		// Model file

	AseScene	m_AseScene;

	INT			m_nMtl	;
	AseMtl*		m_pMtl	;

	INT			m_nGeo	;
	AseGeo*		m_pGeo	;

public:
	CLcAse();
	virtual ~CLcAse();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

protected:
	void	Confirm();

	INT		GetNumMtl();
	INT		GetNumGeo();
	INT		GetNumVtx(INT nGeo);
	INT		GetNumIdx(INT nGeo);

	void*	GetPtVtx(INT nGeo);
	void*	GetPtIdx(INT nGeo);

protected:
	BOOL	CompareAseKey(char* val, char* key);
	INT		Load();
	INT		ParseScene(FILE* fp);
	INT		ParseMaterial(FILE* fp);
	INT		ParseGeometry(FILE* fp);
	INT		ParseAnimation(FILE* fp);

	void	ParseReBuild();
};


#endif

