// Interface for the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcAse_H_
#define _LcAse_H_


#include <vector>


typedef LPDIRECT3DDEVICE9					PDEV;
typedef LPDIRECT3DTEXTURE9					PDTX;



class CLcAse : public ILcMdl
{
public:
	struct AseFce
	{
		union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

		AseFce() : a(0), b(1), c(2){}
		AseFce(WORD A, WORD B, WORD C) : a(A), b(B), c(C){}
		AseFce(WORD* r)					{	a = r[0]; b = r[1];	 c = r[2];	}
		operator WORD*()				{		return (WORD *) &a;			}
		operator const WORD* () const	{		return (CONST WORD *) &a;	}
	};

	typedef char AseKey[64];		// String Keword

	struct AseMtl
	{
		char				sTex[MAX_PATH];
		D3DXIMAGE_INFO		pImg;
		LPDIRECT3DTEXTURE9	pTex;

		AseMtl()
		{
			memset(sTex, 0, sizeof sTex);
			pTex = NULL;
		}

		~AseMtl()
		{
			if(pTex)
			{
				pTex->Release();
				pTex	= NULL;
			}
		}
	};

	struct AseTvtx
	{
		INT		nVt;				// �迭���� ������ �ε���
		FLOAT	u, v, w;			// UVW��ǥ

		AseTvtx() :nVt(-1), u(0), v(0), w(0){}
	};

	struct AseVtx
	{
		FLOAT x, y, z;

		AseVtx() : x(0), y(0), z(0){}
		enum	{FVF = (D3DFVF_XYZ),};
	};

	struct AseVtxN
	{
		FLOAT	Px, Py, Pz;
		FLOAT	Nx, Ny, Nz;

		AseVtxN() : Px(0), Py(0), Pz(0), Nx(0), Ny(0), Nz(0){}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_NORMAL),};
	};

	struct AseVtxUV
	{
		FLOAT	Px, Py, Pz;
		FLOAT	u, v;

		AseVtxUV() : Px(0), Py(0), Pz(0), u(0),v(0){}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_TEX1),};
	};

	struct AseVtxNUV
	{
		FLOAT	Px, Py, Pz;
		FLOAT	Nx, Ny, Nz;
		FLOAT	u, v;

		AseVtxNUV() : Px(0), Py(0), Pz(0), Nx(0), Ny(0), Nz(0), u(0),v(0){}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1),};
	};

	struct AseTM
	{
		D3DXMATRIX	mtW;							// World Matrix
		D3DXMATRIX	mtL;							// Local Matirx

		FLOAT	Px, Py, Pz;
		FLOAT	Rx, Ry, Rz, Rw;
		FLOAT	Sx, Sy, Sz;

		AseTM() : Px(0), Py(0), Pz(0)
					, Rx(0), Ry(0), Rz(0), Rw(0)
					, Sx(0), Sy(0), Sz(0){}
	};

	struct AseScene
	{
		INT		nFrmF;										// First Frame
		INT		nFrmL;										// Last Frame
		INT		nFrmS;										// Frame Speed Per one scecond
		INT		nFrmT;										// Tick per one Frame

		AseScene() : nFrmF(0), nFrmL(0), nFrmS(0), nFrmT(0)
		{}
	};

	struct AseTrack
	{
		FLOAT	x, y, z, w;									// Animation value
		INT		nF;											// Frame Index

		AseTrack() : nF(0), x(0), y(0), z(0), w(0){}
		AseTrack(INT F,FLOAT X,FLOAT Y,FLOAT Z,FLOAT W)
				   : nF(F),x(X),y(Y),z(Z),w(W){}
	};

	struct AseGeo
	{
		char		sNodeCur[64];							// Current Node Name
		char		sNodePrn[64];							// Parent Node Name

		INT			nMtlRef;								// Material Index
		INT			iNumVtx;								// Number of Vertex
		INT			iNumFce;								// Number of Index

		INT			iNumTvtx;								// Number of Vertex
		INT			iNumTfce;								// Number of Index

		AseVtx*		pLstVtx;								// Vertex List
		AseVtx*		pLstNor;								// Normal List
		AseFce*		pLstFce;								// Vertex Face List

		AseTvtx*	pLstTvtx;								// UV List
		AseFce*		pLstTfce;								// UV Face

		AseVtxN*	pVtxN;									// Output Vertex List with Normal
		AseVtxUV*	pVtxUV;									// Output Vertex List with UV
		AseVtxNUV*	pVtxNUV;								// Output Vertex List with Normal, UV

		AseGeo*					pGeoPrn;
		AseTM					TmInf;						// Transform and Movement
		std::vector<AseTrack >	vRot;						// Rotation
		std::vector<AseTrack >	vTrs;						// Translation
		std::vector<AseTrack >	vScl;						// Scaling


		D3DXMATRIX	mtW		;								// World Matrix
		D3DXMATRIX	mtL		;								// Local Matrix
		INT			iNix	;								// Number of Index
		INT			iNvx	;								// Number of Vertex
		AseFce*		pIdx	;								// for indexed buffer
		void*		pVtx	;								// for vertex buffer

		DWORD		dFVF	;
		DWORD		dStride	;								// Zero Stride

		AseGeo()
		{
			nMtlRef = -1;
			iNumVtx = 0;
			iNumFce = 0;
			iNumTvtx= 0;
			iNumTfce = 0;

			pLstVtx = NULL;
			pLstNor	= NULL;
			pLstFce = NULL;

			pLstTvtx= NULL;
			pLstTfce= NULL;

			dFVF	= 0;
			pVtxN	= NULL;
			pVtxUV	= NULL;
			pVtxNUV	= NULL;

			memset(sNodeCur, 0, sizeof sNodeCur);
			memset(sNodePrn, 0, sizeof sNodePrn);

			pGeoPrn		= NULL;


			iNix	=0;
			iNvx	=0;
			pIdx	=NULL;
			pVtx	=NULL;
		}

		~AseGeo()
		{
			if(pLstVtx)
			{
				delete [] pLstVtx;
				pLstVtx= NULL;
			}

			if(pLstNor)
			{
				delete [] pLstNor;
				pLstNor= NULL;
			}

			if(pLstFce)
			{
				delete [] pLstFce;
				pLstFce = NULL;
			}

			if(pLstTvtx)
			{
				delete [] pLstTvtx;
				pLstTvtx= NULL;
			}

			if(pLstTfce)
			{
				delete [] pLstTfce;
				pLstTfce = NULL;
			}

			if(pVtxN)
			{
				delete [] pVtxN;
				pVtxN = NULL;
			}

			if(pVtxUV)
			{
				delete [] pVtxUV;
				pVtxUV = NULL;
			}

			if(pVtxNUV)
			{
				delete [] pVtxNUV;
				pVtxNUV = NULL;
			}

		}
	};


protected:
	PDEV		m_pDev		;
	char		m_sFile[MAX_PATH];

	INT			m_nFrmC		;								// Current Frame
	INT			m_nFrmF		;								// First Frame
	INT			m_nFrmL		;								// Last Frame
	INT			m_nFrmS		;								// Frame Speed
	INT			m_nFrmT		;								// Tick per Frame

	DWORD		m_dBgn		;								// Begin Time
	DWORD		m_dCur		;								// Current Time

	AseScene	m_AseScene	;

	INT			m_nMtl		;
	AseMtl*		m_pMtl		;

	INT			m_nGeo		;
	AseGeo*		m_pGeo		;


public:
	CLcAse();
	virtual ~CLcAse();

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

protected:
	void	Confirm();

	INT		GetNumVtx(INT nGeo);
	INT		GetNumIdx(INT nGeo);

	void*	GetPtVtx(INT nGeo);
	void*	GetPtIdx(INT nGeo);

	void	GetAniFrameInf(INT* nFrmFirst, INT* nFrmLast, INT* nFrmSpeed, INT* nFrmTick);
	INT		GetAniTrack(void* mtA, INT nGeo, INT nFrame);

	BOOL	CompareAseKey(char* val, char* key);
	INT		Load();
	INT		ParseScene(FILE* fp);
	INT		ParseMaterial(FILE* fp);
	INT		ParseGeometry(FILE* fp);
	INT		ParseAnimation(FILE* fp);

	void	ParseReBuild();
};

#endif

