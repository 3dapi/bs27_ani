// Implementation of the CLcAseInst class.
//
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>


#include "ILcMdl.h"
#include "LcAse.h"
#include "LcAseInst.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }


CLcAseInst::TlinkTm::TlinkTm()
{
	nPrn	= -1;

	D3DXMatrixIdentity(&mtW);
	D3DXMatrixIdentity(&mtL);
}


CLcAseInst::CLcAseInst()
{
	m_pDev	= NULL;

	m_nMtl	= 0;
	m_pMtl	= NULL;
	m_nGeo	= 0;
	m_pGeo	= NULL;

	m_pOrg	= NULL;

	m_dFrmCur = 0;
	m_dTimeCur= 0;

	D3DXMatrixIdentity(&m_mtWld);
}

CLcAseInst::~CLcAseInst()
{
	Destroy();
}


INT CLcAseInst::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pOrg	= (CLcAse*)p1;

	m_pDev	= (LPDIRECT3DDEVICE9)m_pOrg->GetDevice();
	m_nMtl	= m_pOrg->GetNumMtl();
	m_pMtl	= m_pOrg->GetMtrl();

	m_nGeo	= m_pOrg->GetNumGeo();
	m_pGeo	= m_pOrg->GetGeometry();


	m_pTM = new TlinkTm[m_nGeo]	;	// World and Animation Matrix


	// Original�� ������ ����
	for(int i=0; i<m_nGeo; ++i)
	{
		m_pTM[i].mtL = m_pGeo[i].mtL;
		m_pTM[i].mtW = m_pGeo[i].mtW;

		m_pTM[i].nPrn= m_pGeo[i].nNodePrn;
	}


	struct Tscene
	{
		char sVer[16];	INT F; INT L; INT S; INT T;
	} t;

	memcpy(&t, m_pOrg->GetHeader(), sizeof(Tscene));

	m_nFrmF	= t.F;		// First Frame
	m_nFrmL	= t.L;		// Last Frame
	m_nFrmS	= t.S;		// Frame Speed
	m_nFrmT	= t.T;		// Tick per Frame

	return 0;
}


void CLcAseInst::Destroy()
{
	m_pOrg = NULL;

	SAFE_DELETE_ARRAY(	m_pTM	);
}






INT CLcAseInst::FrameMove()
{
	int		i = 0;
	INT		nFrame	=0;

	// Frame = FrameSpeed * Time;
	m_dFrmCur = m_nFrmS * m_dTimeCur;

	nFrame	= INT(m_dFrmCur);

	if(nFrame> m_nFrmL)
	{
		// ������ �ð��� ����ð����� �����Ѵ�.
		m_dTimeCur = m_dFrmCur - nFrame;
//		m_dTimeCur = 0;
	}


	for(i=0; i<m_nGeo; ++i)
	{
		TlinkTm*		pTM = &m_pTM[i];
		
		m_pOrg->GetAniTrack(&pTM->mtL, i, (FLOAT)m_dFrmCur);

		// �θ��� ���� ����� ���� �ڽ��� ���� ����� �ϼ��Ѵ�.
		D3DXMATRIX	mtPrn =D3DXMATRIX(1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1);

		if(-1 == pTM->nPrn)
			mtPrn	= m_mtWld;

		if(0 <= pTM->nPrn)
			mtPrn	= m_pTM[pTM->nPrn].mtW;

		pTM->mtW = pTM->mtL * mtPrn;

		int c;
		c=0;
	}


	return 0;
}




void CLcAseInst::Render()
{
	if(!m_pGeo)
		return;

	int	i=0;

	D3DXMATRIX	mtI;
	D3DXMatrixIdentity(&mtI);


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	

	// Texture�� ���� �κ�
	for(i=0; i<m_nGeo; ++i)
	{
		CLcAse::AseGeo*		pGeo = &m_pGeo[i];

		if(NULL == pGeo->m_pVtx)
			continue;

		LPDIRECT3DTEXTURE9	pTx=NULL;

		if(pGeo->nMtlRef>=0)
			pTx = m_pMtl[pGeo->nMtlRef].pTex;
		
//		if(NULL == pTx)
//			continue;

		D3DXMATRIX* pmtWld = &m_pTM[i].mtW;

		m_pDev->SetTransform(D3DTS_WORLD, pmtWld);
		m_pDev->SetFVF(pGeo->m_dFVF);
		m_pDev->SetTexture(0, pTx);
		
		m_pDev->DrawIndexedPrimitiveUP(
									D3DPT_TRIANGLELIST
									, 0						// Minimum Vertex Index
									, pGeo->m_iNvx			// Number vertex indices
									, pGeo->m_iNix			// Primitive Count
									, pGeo->m_pIdx			// IndexData pointer
									, D3DFMT_INDEX16		// Index Data format
									, pGeo->m_pVtx			// Vetex stream zero data
									, pGeo->m_dVtx			// Vertex Stream Zero Stride
									);
	}

	
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);					// �ٽ� Solid
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
}


INT CLcAseInst::SetVal(char* sCmd, void* pData)
{
	if( 0 ==_stricmp("Advance Time", sCmd))
	{
		float	fElapsedTime = *((float*)pData);

		m_dTimeCur += fElapsedTime*0.6f;

		return 0;
	}

	else if( 0 ==_stricmp("World Matrix", sCmd))
	{
		D3DXMATRIX* pTM = (D3DXMATRIX*)pData;

		m_mtWld	= *pTM;
		return 0;
	}


	return -1;
}


INT CLcAseInst::GetVal(char* sCmd, void* v)
{
	return -1;
}




