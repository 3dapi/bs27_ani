// Interface for the CLcAseBInst class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcAseBinInst_H_
#define _LcAseBinInst_H_


#include <vector>


class CLcAseBInst : public ILcMdl
{
public:
	struct TlinkTm
	{
		D3DXMATRIX	mtW		;		// World Matrix
		D3DXMATRIX	mtL		;		// Local Matrix

		INT			nPrn	;		// Parent Node Index

		TlinkTm();
	};

protected:
	LPDIRECT3DDEVICE9	m_pDev	;
	
	CLcAseB*		m_pOrg	;

	INT			m_nFrmF		;		// First Frame
	INT			m_nFrmL		;		// Last Frame
	INT			m_nFrmS		;		// Frame Speed
	INT			m_nFrmT		;		// Tick per Frame

	DOUBLE		m_dFrmCur	;		// Current Frame
	DOUBLE		m_dTimeCur	;		// Current Time

	INT				m_nMtl	;
	CLcAseB::Tmtl*	m_pMtl	;

	INT				m_nGeo	;
	CLcAseB::Tgeo*	m_pGeo	;


	D3DXMATRIX	m_mtWld		;	// World Matrix
	TlinkTm*	m_pTM		;	// World and Animation Matrix


public:
	CLcAseBInst();
	virtual ~CLcAseBInst();

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		SetVal(char* sCmd, void* pData);
	virtual INT		GetVal(char* sCmd, void* pData);
};

#endif

