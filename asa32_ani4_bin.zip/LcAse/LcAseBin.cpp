// Implementation of the CLcAseB class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>


#include "ILcMdl.h"
#include "LcAseBin.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }



CLcAseB::Tmtl::Tmtl()
{
	memset(sTex, 0, sizeof sTex);
	pTex = NULL;
}

CLcAseB::Tmtl::~Tmtl()
{
	SAFE_RELEASE(	pTex	);
}


CLcAseB::Tgeo::Tgeo()
{
	nMtl	= -1;

	memset(sName, 0, sizeof sName);

	nPrn	= -1;
	iNix	= 0;
	iNvx	= 0;
	pIdx	= NULL;
	pVtx	= NULL;
	dFVF	= 0;
	dVtx	= 0;


	D3DXMatrixIdentity(&mtTmL);
	D3DXMatrixIdentity(&mtW);
	D3DXMatrixIdentity(&mtL);
	
	nRot	= 0;
	nTrs	= 0;
	vRot	= NULL;
	vTrs	= NULL;
}

CLcAseB::Tgeo::~Tgeo()
{
	SAFE_DELETE_ARRAY(	pIdx	);

	if(pVtx)
	{
		if(dFVF == (DWORD)Tvtx::FVF)
		{
			Tvtx* p = (Tvtx*)pVtx;
			delete [] p;
		}

		else if(dFVF == (DWORD)TvtxUV::FVF)
		{
			TvtxUV* p = (TvtxUV*)pVtx;
			delete [] p;
		}

		pVtx = NULL;
	}

	nPrn	= -1;
	iNix	= 0;
	iNvx	= 0;
	dFVF	= 0;
	dVtx	= 0;
}


CLcAseB::CLcAseB()
{
	m_pDev	= NULL;

	m_nMtl	= 0;
	m_pMtl	= NULL;

	m_nGeo	= 0;
	m_pGeo	= NULL;

	m_dFrmCur = 0;
	m_dTimeCur= 0;
}

CLcAseB::~CLcAseB()
{
	Destroy();
}


INT CLcAseB::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev	= (LPDIRECT3DDEVICE9)p1;
	strcpy(m_sFile, (char*)p2);


	if(FAILED(Load()))
		return -1;

	return 0;
}


void CLcAseB::Destroy()
{
	m_nMtl	= 0;
	m_nGeo	= 0;

	SAFE_DELETE_ARRAY(	m_pMtl	);	
	SAFE_DELETE_ARRAY(	m_pGeo	);
}






INT CLcAseB::FrameMove()
{
	int		i = 0;
	INT		nFrame	=0;

	// Frame = FrameSpeed * Time;
	m_dFrmCur = m_Scene.nFrmS * m_dTimeCur;

	nFrame	= INT(m_dFrmCur);

	if(nFrame>= m_Scene.nFrmL)
	{
		// ������ �ð��� ����ð����� �����Ѵ�.
		m_dTimeCur = m_dFrmCur - nFrame;
	}

	for(i=0; i<m_nGeo; ++i)
	{
		Tgeo*		pGeo = &m_pGeo[i];
		
		this->GetAniTrack(&pGeo->mtL, i, (float)m_dFrmCur);

		// �θ��� ���� ����� ���� �ڽ��� ���� ����� �ϼ��Ѵ�.
		D3DXMATRIX	mtPrn;
		D3DXMatrixIdentity(&mtPrn);

		if(0 <= pGeo->nPrn)
			mtPrn	= m_pGeo[pGeo->nPrn].mtW;

		pGeo->mtW = pGeo->mtL * mtPrn;

		int c;
		c=0;
	}


	return 0;
}




void CLcAseB::Render()
{
	if(!m_pGeo)
		return;

	int	i=0;

	D3DXMATRIX	mtI;
	D3DXMatrixIdentity(&mtI);


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	

	// Texture�� ���� �κ�
	for(i=0; i<m_nGeo; ++i)
	{
		Tgeo*		pGeo = &m_pGeo[i];

		if(NULL == pGeo->pVtx)
			continue;

		LPDIRECT3DTEXTURE9	pTx=NULL;

		if( 0<= pGeo->nMtl)
			pTx = m_pMtl[pGeo->nMtl].pTex;
		
		if(NULL == pTx)
			continue;


		m_pDev->SetTransform(D3DTS_WORLD, &(pGeo->mtW));
		m_pDev->SetFVF(pGeo->dFVF);
		m_pDev->SetTexture(0, pTx);
		
		m_pDev->DrawIndexedPrimitiveUP(
									D3DPT_TRIANGLELIST
									, 0						// Minimum Vertex Index
									, pGeo->iNvx			// Number vertex indices
									, pGeo->iNix			// Primitive Count
									, pGeo->pIdx			// IndexData pointer
									, D3DFMT_INDEX16		// Index Data format
									, pGeo->pVtx			// Vetex stream zero data
									, pGeo->dVtx			// Vertex Stream Zero Stride
									);
	}

	
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);					// �ٽ� Solid
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
}


INT CLcAseB::SetVal(char* sCmd, void* pData)
{
	if( 0 ==_stricmp("Advance Time", sCmd))
	{
		float	fElapsedTime = *((float*)pData);

		m_dTimeCur += fElapsedTime;

		return 0;
	}

	else if( 0 ==_stricmp("World Matrix", sCmd))
	{
		D3DXMATRIX* pTM = (D3DXMATRIX*)pData;

		m_mtWld	= *pTM;
		return 0;
	}


	return -1;
}


INT CLcAseB::GetVal(char* sCmd, void* v)
{
	return -1;
}


INT CLcAseB::GetAniTrack(void* mtOut, INT nGeo, FLOAT dFrame)
{
	INT			i=0;

	Tgeo*		pGeo	= &m_pGeo[nGeo];
	D3DXMATRIX	mtA;

	INT			iSizeR = pGeo->nRot;
	INT			iSizeP = pGeo->nTrs;

	
	D3DXMatrixIdentity(&mtA);

	
	if(iSizeR && pGeo->vRot[0].nF <=dFrame)
	{
		INT nFrm = pGeo->vRot[0].nF;
		INT nIdx;

		if(1 == iSizeR)
		{
			D3DXQUATERNION q;

			nIdx =0;

			q.x = pGeo->vRot[nIdx].x;
			q.y = pGeo->vRot[nIdx].y;
			q.z = pGeo->vRot[nIdx].z;
			q.w = pGeo->vRot[nIdx].w;

			D3DXMatrixRotationQuaternion(&mtA, &q);
		}

		else if(pGeo->vRot[iSizeR-1].nF <=dFrame)
		{
			D3DXQUATERNION q;

			nIdx = iSizeR-1;

			q.x = pGeo->vRot[nIdx].x;
			q.y = pGeo->vRot[nIdx].y;
			q.z = pGeo->vRot[nIdx].z;
			q.w = pGeo->vRot[nIdx].w;

			D3DXMatrixRotationQuaternion(&mtA, &q);
		}

		else
		{
			for(i=0; i<iSizeR-1; ++i)
			{
				if(pGeo->vRot[i].nF <=dFrame && dFrame <pGeo->vRot[i+1].nF)
				{
					D3DXQUATERNION q;
					D3DXQUATERNION q1;
					D3DXQUATERNION q2;

					nIdx = i;

					q1.x = pGeo->vRot[nIdx].x;
					q1.y = pGeo->vRot[nIdx].y;
					q1.z = pGeo->vRot[nIdx].z;
					q1.w = pGeo->vRot[nIdx].w;

					q2.x = pGeo->vRot[nIdx+1].x;
					q2.y = pGeo->vRot[nIdx+1].y;
					q2.z = pGeo->vRot[nIdx+1].z;
					q2.w = pGeo->vRot[nIdx+1].w;

					FLOAT	w = (dFrame - pGeo->vRot[i].nF)/(pGeo->vRot[i+1].nF- pGeo->vRot[i].nF);

					// q = q1  + w * (q2-q1);
					D3DXQuaternionSlerp(&q, &q1, &q2, w);

					D3DXMatrixRotationQuaternion(&mtA, &q);
					break;
				}
			}
		}
	}

	else
	{
		mtA = pGeo->mtTmL;
	}


	if(iSizeP && pGeo->vTrs[0].nF <=dFrame)
	{
		INT nIdx;

		if(1 == iSizeP)
		{
			D3DXVECTOR3 p;

			nIdx =0;
			p.x = pGeo->vTrs[nIdx].x;
			p.y = pGeo->vTrs[nIdx].y;
			p.z = pGeo->vTrs[nIdx].z;

			mtA._41 = p.x;
			mtA._42 = p.y;
			mtA._43 = p.z;
		}

		else if(pGeo->vTrs[iSizeP-1].nF <=dFrame)
		{
			D3DXVECTOR3 p;

			nIdx = iSizeP-1;
			p.x = pGeo->vTrs[nIdx].x;
			p.y = pGeo->vTrs[nIdx].y;
			p.z = pGeo->vTrs[nIdx].z;

			mtA._41 = p.x;
			mtA._42 = p.y;
			mtA._43 = p.z;
		}

		else
		{
			for(i=0; i<iSizeP-1; ++i)
			{
				if(pGeo->vTrs[i].nF <=dFrame && dFrame <pGeo->vTrs[i+1].nF)
				{
					D3DXVECTOR3 p;
					D3DXVECTOR3 p1;
					D3DXVECTOR3 p2;

					nIdx = i;

					p1.x = pGeo->vTrs[nIdx].x;
					p1.y = pGeo->vTrs[nIdx].y;
					p1.z = pGeo->vTrs[nIdx].z;

					p2.x = pGeo->vTrs[nIdx+1].x;
					p2.y = pGeo->vTrs[nIdx+1].y;
					p2.z = pGeo->vTrs[nIdx+1].z;


					FLOAT	w = (dFrame- pGeo->vTrs[i].nF)/(pGeo->vTrs[i+1].nF- pGeo->vTrs[i].nF);

					p = p1  + w * (p2-p1);
					mtA._41 = p.x;	mtA._42 = p.y;	mtA._43 = p.z;
					break;
				}
			}
		}
	}
	else
	{
		mtA._41 = pGeo->mtTmL._41;
		mtA._42 = pGeo->mtTmL._42;
		mtA._43 = pGeo->mtTmL._43;
	}


	*((D3DXMATRIX*) mtOut) = mtA;
	
	return 0;
}






INT CLcAseB::Load()
{
	FILE*	fp;
	INT		n=0;
	INT		j=0;

	fp = fopen(m_sFile, "rb");
	
	if(NULL == fp)
		return -1;


	//1. Reading Header
	fread(&m_Scene, sizeof(Thead), 1, fp);	// Scene Info
	fread(&m_nMtl , sizeof(INT), 1, fp);	// Material ��
	fread(&m_nGeo , sizeof(INT), 1, fp);	// Geometry ��

	fseek(fp, LCM_HEADER_SIZE, SEEK_SET);	// chunck ��ŭ �̵�


	m_pMtl = new Tmtl[m_nMtl];
	m_pGeo = new Tgeo[m_nGeo];


	//2. Reading Material
	for(n=0; n<m_nMtl; ++n)
	{
		Tmtl*	pDest	= &m_pMtl[n];
		fread(pDest->sTex, 1, LCM_TX_NAME, fp);
	}


	//3. Reading Geometry Info
	for(n=0; n<m_nGeo; ++n)
	{
		Tgeo*	pDest	= &m_pGeo[n];

		fread(pDest->sName	, sizeof(char ), 32, fp);		// Current Node Name
		fread(&pDest->nPrn	, sizeof(INT  ),  1, fp);		// Parent Node Index
		fread(&pDest->nMtl	, sizeof(INT  ),  1, fp);		// Material Index

		fread(&pDest->iNix	, sizeof(INT  ),  1, fp);		// Number of Index
		fread(&pDest->iNvx	, sizeof(INT  ),  1, fp);		// Number of Vertex
		fread(&pDest->dFVF	, sizeof(DWORD),  1, fp);		// FVF
		fread(&pDest->dVtx	, sizeof(DWORD),  1, fp);		// Zero Stride

		fread(&pDest->mtW	, sizeof(FLOAT), 16, fp);		// World Matrix
		fread(&pDest->mtL	, sizeof(FLOAT), 16, fp);		// Local Matrix
		fread(&pDest->mtTmL	, sizeof(FLOAT), 16, fp);		// Transform and Movement

		fread(&pDest->nRot	, sizeof(INT  ),  1, fp);		// Rotaion Number of Animation
		fread(&pDest->nTrs	, sizeof(INT  ),  1, fp);		// Translation Number of Animation
	}


	//4. Memory Alloc
	for(n=0; n<m_nGeo; ++n)
	{
		Tgeo*	pDest	= &m_pGeo[n];

		if(pDest->iNix)
			pDest->pIdx = new Tidx[pDest->iNix];

		if(pDest->iNvx)
		{
			if(pDest->dFVF == (DWORD)Tvtx::FVF)
				pDest->pVtx = new Tvtx[pDest->iNvx];

			else if(pDest->dFVF == (DWORD)TvtxUV::FVF)
				pDest->pVtx = new TvtxUV[pDest->iNvx];
		}

		if(pDest->nRot)
			pDest->vRot = new Ttrack[pDest->nRot];

		if(pDest->nTrs)
			pDest->vTrs= new Ttrack[pDest->nTrs];
	}


	//5. Reading Vertex.
	for(n=0; n<m_nGeo; ++n)
	{
		Tgeo*	pDest	= &m_pGeo[n];

		// Reading Index Buffer
		if(pDest->iNix)
			fread(pDest->pIdx, sizeof(Tidx), pDest->iNix, fp);
	
		if(pDest->iNvx)
			fread(pDest->pVtx, pDest->dVtx, pDest->iNvx, fp);
	}

	//6. Reading Animation.
	for(n=0; n<m_nGeo; ++n)
	{
		Tgeo*	pDest	= &m_pGeo[n];

		// Reading Rotation
		if(0< pDest->nRot)
			fread(pDest->vRot, sizeof(Ttrack), pDest->nRot, fp);

		// Reading Translation
		if(0< pDest->nTrs)
			fread(pDest->vTrs, sizeof(Ttrack), pDest->nTrs, fp);
	}


	fclose(fp);





	//7. Load Texture
	DWORD		color		= 0x00FFFFFF;
	DWORD		Filter		= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR);
	DWORD		MipFilter	= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR);
	D3DFORMAT	d3dFormat	= D3DFMT_UNKNOWN;

	char dir[_MAX_DIR]={0};
	
	_splitpath( m_sFile, NULL, dir, NULL, NULL);


	for(n=0; n<m_nMtl; ++n)
	{
		Tmtl*		pMtl = &m_pMtl[n];

		char sFile[_MAX_PATH];

		sprintf(sFile, "%s%s", dir, pMtl->sTex);

		if ( FAILED(D3DXCreateTextureFromFileEx(m_pDev
											, sFile
											, D3DX_DEFAULT
											, D3DX_DEFAULT
											, D3DX_DEFAULT
											, 0
											, d3dFormat
											, D3DPOOL_MANAGED
											, Filter
											, MipFilter
											, color
											, &pMtl->pImg
											, NULL
											, &pMtl->pTex
											)) )
		{
			MessageBox(GetActiveWindow(), "Cannot Read Model Texture", "Error", 0);
		}
	}


	return 0;
}

