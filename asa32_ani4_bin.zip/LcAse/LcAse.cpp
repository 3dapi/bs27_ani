// Implementation of the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <stdio.h>
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>


#include "ILcMdl.h"
#include "LcAse.h"


#define MAX_PARSE_LINE	512


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CLcAse::CLcAse()
{
	m_pDev	= NULL;

	m_nMtl	= 0;
	m_pMtl	= NULL;

	m_nGeo	= 0;
	m_pGeo	= NULL;

	m_dFrmCur = 0;
	m_dTimeCur= 0;
}

CLcAse::~CLcAse()
{
	Destroy();
}


INT CLcAse::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev	= (LPDIRECT3DDEVICE9)p1;
	strcpy(m_sFile, (char*)p2);


	if(FAILED(Load()))
		return -1;

	SetupRenderData();
	
	Confirm();

	SaveToAsmBin();
	SaveToAsmTxt();


	return 0;
}


void CLcAse::Destroy()
{
	m_nMtl	= 0;
	m_nGeo	= 0;

	SAFE_DELETE_ARRAY(	m_pGeo	);
	SAFE_DELETE_ARRAY(	m_pMtl	);
}



INT CLcAse::FrameMove()
{
	INT		i = 0;
	INT		nFrame	=0;

	// Frame = FrameSpeed * Time;
	m_dFrmCur = m_Scene.nFrmS * m_dTimeCur;

	nFrame	= INT(m_dFrmCur);

	if(nFrame>= m_Scene.nFrmL)
	{
		// ������ �ð��� ����ð����� �����Ѵ�.
		m_dTimeCur = m_dFrmCur - nFrame;
	}

	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*		pGeo = &m_pGeo[i];
		
		this->GetAniTrack(&pGeo->mtL, i, (FLOAT)m_dFrmCur);

		// �θ��� ���� ����� ���� �ڽ��� ���� ����� �ϼ��Ѵ�.
		D3DXMATRIX	mtPrn;
		D3DXMatrixIdentity(&mtPrn);

		if(0 <= pGeo->nNodePrn)
			mtPrn	= m_pGeo[pGeo->nNodePrn].mtW;

		pGeo->mtW = pGeo->mtL * mtPrn;

		INT c;
		c=0;
	}


	return 0;
}




void CLcAse::Render()
{
	if(!m_pGeo)
		return;

	INT	i=0;

	D3DXMATRIX	mtI;
	D3DXMatrixIdentity(&mtI);


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	

	// Texture�� ���� �κ�
	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*		pGeo = &m_pGeo[i];

		if(NULL == pGeo->m_pVtx)
			continue;

		LPDIRECT3DTEXTURE9	pTx=NULL;

		if(pGeo->nMtlRef>=0)
			pTx = m_pMtl[pGeo->nMtlRef].pTex;
		
//		if(NULL == pTx)
//			continue;


		m_pDev->SetTransform(D3DTS_WORLD, &(pGeo->mtW));
		m_pDev->SetFVF(pGeo->m_dFVF);
		m_pDev->SetTexture(0, pTx);
		
		m_pDev->DrawIndexedPrimitiveUP(
									D3DPT_TRIANGLELIST
									, 0						// Minimum Vertex Index
									, pGeo->m_iNvx			// Number vertex indices
									, pGeo->m_iNix			// Primitive Count
									, pGeo->m_pIdx			// IndexData pointer
									, D3DFMT_INDEX16		// Index Data format
									, pGeo->m_pVtx			// Vetex stream zero data
									, pGeo->m_dVtx			// Vertex Stream Zero Stride
									);
	}

	
	m_pDev->SetTransform(D3DTS_WORLD, &mtI);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);					// �ٽ� Solid
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
}


INT CLcAse::SetVal(char* sCmd, void* pData)
{
	if( 0 ==_stricmp("Advance Time", sCmd))
	{
		float	fElapsedTime = *((float*)pData);

		m_dTimeCur += fElapsedTime;

		return 0;
	}

	else if( 0 ==_stricmp("World Matrix", sCmd))
	{
		D3DXMATRIX* pTM = (D3DXMATRIX*)pData;

		m_mtWld	= *pTM;
		return 0;
	}


	return -1;
}


INT CLcAse::GetVal(char* sCmd, void* v)
{
	return -1;
}


INT CLcAse::GetNumVtx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];
	
	return pGeo->m_iNvx;
}

INT CLcAse::GetNumIdx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];
	
	return pGeo->m_iNix;
}

void*  CLcAse::GetPtVtx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];
	
	return pGeo->m_pVtx;
}

void*  CLcAse::GetPtIdx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];

	return pGeo->m_pIdx;
}


INT CLcAse::GetAniTrack(void* mtOut, INT nGeo, FLOAT dFrame)
{
	INT			i=0;

	AseGeo*		pGeo	= &m_pGeo[nGeo];
	D3DXMATRIX	mtA;

	INT			iSizeR = pGeo->vRot.size();
	INT			iSizeP = pGeo->vTrs.size();

	
	D3DXMatrixIdentity(&mtA);

	
	if(iSizeR && pGeo->vRot[0].nF <=dFrame)
	{
		INT nFrm = pGeo->vRot[0].nF;
		INT nIdx;

		if(1 == iSizeR)
		{
			D3DXQUATERNION q;

			nIdx =0;

			q.x = pGeo->vRot[nIdx].x;
			q.y = pGeo->vRot[nIdx].y;
			q.z = pGeo->vRot[nIdx].z;
			q.w = pGeo->vRot[nIdx].w;

			D3DXMatrixRotationQuaternion(&mtA, &q);
		}

		else if(pGeo->vRot[iSizeR-1].nF <=dFrame)
		{
			D3DXQUATERNION q;

			nIdx = iSizeR-1;

			q.x = pGeo->vRot[nIdx].x;
			q.y = pGeo->vRot[nIdx].y;
			q.z = pGeo->vRot[nIdx].z;
			q.w = pGeo->vRot[nIdx].w;

			D3DXMatrixRotationQuaternion(&mtA, &q);
		}

		else
		{
			for(i=0; i<iSizeR-1; ++i)
			{
				if(pGeo->vRot[i].nF <=dFrame && dFrame <pGeo->vRot[i+1].nF)
				{
					D3DXQUATERNION q;
					D3DXQUATERNION q1;
					D3DXQUATERNION q2;

					nIdx = i;

					q1.x = pGeo->vRot[nIdx].x;
					q1.y = pGeo->vRot[nIdx].y;
					q1.z = pGeo->vRot[nIdx].z;
					q1.w = pGeo->vRot[nIdx].w;

					q2.x = pGeo->vRot[nIdx+1].x;
					q2.y = pGeo->vRot[nIdx+1].y;
					q2.z = pGeo->vRot[nIdx+1].z;
					q2.w = pGeo->vRot[nIdx+1].w;

					FLOAT	w = (dFrame - pGeo->vRot[i].nF)/(pGeo->vRot[i+1].nF- pGeo->vRot[i].nF);

					// q = q1  + w * (q2-q1);
					D3DXQuaternionSlerp(&q, &q1, &q2, w);

					D3DXMatrixRotationQuaternion(&mtA, &q);
					break;
				}
			}
		}
	}

	else
	{
		mtA = pGeo->TmInf.mtL;
	}


	if(iSizeP && pGeo->vTrs[0].nF <=dFrame)
	{
		INT nIdx;

		if(1 == iSizeP)
		{
			D3DXVECTOR3 p;

			nIdx =0;
			p.x = pGeo->vTrs[nIdx].x;
			p.y = pGeo->vTrs[nIdx].y;
			p.z = pGeo->vTrs[nIdx].z;

			mtA._41 = p.x;
			mtA._42 = p.y;
			mtA._43 = p.z;
		}

		else if(pGeo->vTrs[iSizeP-1].nF <=dFrame)
		{
			D3DXVECTOR3 p;

			nIdx = iSizeP-1;
			p.x = pGeo->vTrs[nIdx].x;
			p.y = pGeo->vTrs[nIdx].y;
			p.z = pGeo->vTrs[nIdx].z;

			mtA._41 = p.x;
			mtA._42 = p.y;
			mtA._43 = p.z;
		}

		else
		{
			for(i=0; i<iSizeP-1; ++i)
			{
				if(pGeo->vTrs[i].nF <=dFrame && dFrame <pGeo->vTrs[i+1].nF)
				{
					D3DXVECTOR3 p;
					D3DXVECTOR3 p1;
					D3DXVECTOR3 p2;

					nIdx = i;

					p1.x = pGeo->vTrs[nIdx].x;
					p1.y = pGeo->vTrs[nIdx].y;
					p1.z = pGeo->vTrs[nIdx].z;

					p2.x = pGeo->vTrs[nIdx+1].x;
					p2.y = pGeo->vTrs[nIdx+1].y;
					p2.z = pGeo->vTrs[nIdx+1].z;


					FLOAT	w = (dFrame- pGeo->vTrs[i].nF)/(pGeo->vTrs[i+1].nF- pGeo->vTrs[i].nF);

					p = p1  + w * (p2-p1);
					mtA._41 = p.x;	mtA._42 = p.y;	mtA._43 = p.z;
					break;
				}
			}
		}
	}
	else
	{
		mtA._41 = pGeo->TmInf.mtL._41;
		mtA._42 = pGeo->TmInf.mtL._42;
		mtA._43 = pGeo->TmInf.mtL._43;
	}


	*((D3DXMATRIX*) mtOut) = mtA;
	
	return 0;
}



BOOL CLcAse::CompareAseKey(char* val, char* key)
{
	return (0 == _strnicmp(val, key, strlen(key) ) ) ? 1: 0;
}



INT CLcAse::Load()
{
	FILE*	fp;

	fp = fopen(m_sFile, "rt");
	
	if(NULL == fp)
		return -1;


	ParseScene(fp);
	ParseMaterial(fp);
	ParseGeometry(fp);
	ParseAnimation(fp);

	fclose(fp);

	return 0;
}
